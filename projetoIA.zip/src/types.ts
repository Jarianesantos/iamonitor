export type OperationalProfile = "transit" | "dp" | "maneuver" | "port";

export type BatteryVoltage = "125Vcc";

export interface TelemetryState {
  hourTimestamp: number; // 0 to 24 simulation hour
  timeString: string;
  loadDemand: number; // kW required by the vessel
  genPower: [number, number, number, number]; // kW produced by generators 1, 2, 3, 4
  batteryPower: number; // kW (positive = discharging, negative = charging, 0 = idle)
  batterySoc: number; // State of Charge (%)
  hotelLoad: number; // Auxiliary loads (kW)
  propulsionLoad: number; // Propulsion motor power (kW)
  fuelFlowRate: number; // L/h
  co2FlowRate: number; // kg/h
  systemEfficiency: number; // overall % efficiency
  activeGeneratorsCount: number;
}

export interface SimulationParams {
  profile: OperationalProfile;
  vesselSpeed: number; // knots
  seaStateBeaufort: number; // 1 to 6
  hotelLoadSetting: number; // kW (auxiliary loads)
  batteryVoltage: BatteryVoltage;
  batteryCount: number; // quantity of batteries
  batteryAmperage: number; // amperage / continuous current of each battery (A or Ah)
  aiOptimized: boolean; // active LSTM + MPC AI control
}

export interface ComparativeMetrics {
  conventional: {
    fuelTotal: number; // total L for 24h
    co2Total: number; // total kg for 24h
    avgEfficiency: number; // %
    blackoutRisks: number;
  };
  hybridLithium: {
    fuelTotal: number;
    co2Total: number;
    avgEfficiency: number;
    fuelSavingsPercent: number;
    co2SavingsPercent: number;
    efficiencyGainPp: number;
    blackoutRisks: number;
  };
  hybridAi: {
    fuelTotal: number;
    co2Total: number;
    avgEfficiency: number;
    fuelSavingsPercent: number;
    co2SavingsPercent: number;
    efficiencyGainPp: number;
    blackoutRisks: number;
  };
}

export interface AiAdvisoryMessage {
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}
