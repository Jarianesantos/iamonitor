import React, { useState, useEffect, useRef } from "react";
import {
  Ship,
  Power,
  ShieldCheck,
  ShieldAlert,
  Cpu,
  Zap,
  Gauge,
  Flame,
  Activity,
  Compass,
  Info,
  CheckCircle2,
  Calendar,
  Layers,
  Thermometer,
  Anchor,
  Send,
  Loader2,
  Check,
  AlertTriangle,
  Play,
  Pause,
  ArrowRight,
  TrendingDown,
  LineChart,
  RefreshCw,
  Award
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { OperationalProfile, BatteryVoltage, TelemetryState, SimulationParams, AiAdvisoryMessage, ComparativeMetrics } from "./types";
import { VESSEL_SPECIFICATIONS, SODIUM_BATTERY_SPECS, SIMULATION_PROFILES, AI_PRESETS, PRESETS_ANSWERS } from "./constants";

export default function App() {
  // Primary Parameters State
  const [params, setParams] = useState<SimulationParams>({
    profile: "dp", // Default to Dynamic Positioning as it is the most critical AI use-case
    vesselSpeed: 4, // knots
    seaStateBeaufort: 3, // average
    hotelLoadSetting: 450, // kW
    batteryVoltage: "125Vcc", // brochure standard
    batteryCount: 75, // default quantity requested
    batteryAmperage: 80, // default amperage requested
    aiOptimized: true // AI active by default
  });

  // Fault Injection State
  const [faults, setFaults] = useState({
    generator1Failure: false,
    batteryOverheat: false,
    aiCommunicationLoss: false,
    busShortCircuit: false,
  });

  const [isFaultsExpanded, setIsFaultsExpanded] = useState<boolean>(false);

  const [selectedHour, setSelectedHour] = useState<number>(14); // start at active afternoon hour
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [advisoryMessages, setAdvisoryMessages] = useState<AiAdvisoryMessage[]>([
    {
      role: "assistant",
      content: "Saudações, Comandante. Eu sou o Assistente IA de Propulsão Híbrida. Estou monitorando os sistemas do PSV World Diamond em tempo real.\n\nNo momento, operamos sob Gerenciamento Inteligente LSTM + MPC. O modelo prevê a demanda de ondas e hotelaria para os próximos 15 minutos, enquanto o controle preditivo distribui a carga ideal entre os Geradores e o Banco de Baterias de Sódio.\n\nComo posso ajudá-lo na otimização de combustível e segurança da embarcação hoje?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [userQuery, setUserQuery] = useState<string>("");
  const [aiLoading, setAiLoading] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<"telemetry" | "battery" | "comparison" | "faq">("telemetry");
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);

  const chatEndRef = useRef<HTMLDivElement>(null);
  const playIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Auto-advance simulation loop
  useEffect(() => {
    if (isPlaying) {
      playIntervalRef.current = setInterval(() => {
        setSelectedHour((prev) => (prev + 1) % 24);
      }, 3500); // advance hour every 3.5 seconds
    } else {
      if (playIntervalRef.current) {
        clearInterval(playIntervalRef.current);
      }
    }
    return () => {
      if (playIntervalRef.current) clearInterval(playIntervalRef.current);
    };
  }, [isPlaying]);

  // Scroll chat to bottom
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [advisoryMessages]);

  // Modify speed automatically when changing profiles to match sea reality
  const handleProfileChange = (profile: OperationalProfile) => {
    let speed = 4;
    let hotelLoad = 450;
    if (profile === "port") {
      speed = 0;
      hotelLoad = 250;
    } else if (profile === "transit") {
      speed = 12;
      hotelLoad = 350;
    } else if (profile === "maneuver") {
      speed = 6;
      hotelLoad = 600;
    } else if (profile === "dp") {
      speed = 3;
      hotelLoad = 500;
    }
    setParams((prev) => ({
      ...prev,
      profile,
      vesselSpeed: speed,
      hotelLoadSetting: hotelLoad
    }));
  };

  // Calculations for current telemetry point
  const getTelemetryData = (hour: number, currentParams: SimulationParams): TelemetryState => {
    const profilePoints = SIMULATION_PROFILES[currentParams.profile];
    const point = profilePoints[hour];

    // Speed resistance formula (drag is approximately cubic to speed for displacement vessels)
    // propulsion power needed = dragFactor * Constant * speed^2.5
    const designBaseSpeed = currentParams.profile === "transit" ? 12 : currentParams.profile === "dp" ? 3 : 6;
    const speedRatio = currentParams.vesselSpeed > 0 
      ? Math.pow(currentParams.vesselSpeed / (designBaseSpeed || 1), 2.4)
      : 0;

    // Beaufort wind/waves drag additions (+12% loading per Beaufort scale degree above 1)
    const environmentalDragCoeff = 1 + (currentParams.seaStateBeaufort - 1) * 0.12;
    
    // Total variable propulsion load simulation
    const basePropkW = currentParams.profile === "port" ? 0 : point.baseDemandkW * 0.75;
    const computedPropulsionkW = Math.round(basePropkW * speedRatio * environmentalDragCoeff);
    
    const hotelLoadkW = currentParams.hotelLoadSetting;
    let totalLoadkW = computedPropulsionkW + hotelLoadkW;
    if (faults.busShortCircuit) {
      totalLoadkW += 500; // 500kW loss due to ground faults/harmonics
    }

    // AI active control vs Conventional traditional reduntant split
    const activeGens: [number, number, number, number] = [0, 0, 0, 0];
    let batterykW = 0; // positive is discharging, negative charging
    let rawGensOnlineCount = 0;
    let dieselEfficiency = 72; // conventional standard low efficiency

    const maxG1G2 = 1200;
    const maxG3G4 = 925;

    // Initial battery state of charge (SoC fluctuates around 24 hours)
    // We simulate a charging-discharging cycle based on hour and load peaks
    const baseSoc = 62;
    const socFluctuation = 18 * Math.sin((hour - 4) * Math.PI / 12);
    let computedSoc = Math.round(baseSoc + socFluctuation);
    if (computedSoc < 15) computedSoc = 15;
    if (computedSoc > 95) computedSoc = 95;

    const isAiActive = currentParams.aiOptimized && !faults.aiCommunicationLoss;

    if (isAiActive) {
      // AI Optimal Controller (LSTM+MPC)
      // Peak shaving and optimized power-sharing!
      // LSTM predicts high loads, MPC decides to keep large diesel generators at high load (75-85% optimal efficiency sweet-spot)
      // and cushions sudden wind-driven peaks using Sodium Battery discharging.
      // During lower load points, generators charge the battery at optimal curve.
      
      const peakLimit = faults.busShortCircuit ? 1500 : 2200;
      if (faults.batteryOverheat) {
        batterykW = 0;
      } else if (totalLoadkW > peakLimit && computedSoc > 25) {
        // Discharge battery to shave peak
        batterykW = Math.min(totalLoadkW - peakLimit, 650); // up to 650kW battery backup
      } else if (totalLoadkW < 1500 && computedSoc < 85) {
        // Excess capacity is used to charge battery in optimal diesel fuel spot
        batterykW = -Math.round(Math.min((1500 - totalLoadkW) * 0.6, 400));
      }

      const gensDemand = totalLoadkW + batterykW;
      
      // Select generator combination that operates closest to 80% individual loading
      if (gensDemand < 400) {
        // Port mode or low load: G3 (small engine) online at highly optimized load
        activeGens[2] = gensDemand;
        rawGensOnlineCount = 1;
      } else if (gensDemand < 1000) {
        // G1 (large engine) online in highly efficient 75% loading spot
        activeGens[0] = gensDemand;
        rawGensOnlineCount = 1;
      } else if (gensDemand < 1800) {
        // G1 & G3 online
        const half = Math.round(gensDemand / 2);
        activeGens[0] = Math.min(half, maxG1G2);
        activeGens[2] = gensDemand - activeGens[0];
        rawGensOnlineCount = 2;
      } else if (gensDemand < 2900) {
        // G1, G2 and maybe G3 online
        const segment = Math.round(gensDemand / 2);
        activeGens[0] = Math.min(segment, maxG1G2);
        activeGens[1] = Math.min(segment, maxG1G2);
        activeGens[2] = gensDemand - activeGens[0] - activeGens[1];
        rawGensOnlineCount = activeGens[2] > 0 ? 3 : 2;
      } else {
        // All active n-way distribution
        const share = Math.round(gensDemand / 4);
        activeGens[0] = Math.min(share, maxG1G2);
        activeGens[1] = Math.min(share, maxG1G2);
        activeGens[2] = Math.min(share, maxG3G4);
        activeGens[3] = gensDemand - activeGens[0] - activeGens[1] - activeGens[2];
        rawGensOnlineCount = 4;
      }

      dieselEfficiency = 93; // Highly efficient system
    } else {
      // Conventional traditional controller (Manual schedule)
      // Safety regulations force many generators online simultaneously as manual spin reserves,
      // creating massive inefficiencies! No battery participation (IDLE).
      batterykW = 0;
      
      if (currentParams.profile === "port") {
        activeGens[2] = totalLoadkW; // Only G3
        rawGensOnlineCount = 1;
      } else if (currentParams.profile === "dp") {
        // REDUNDANCY RULE: ALL 4 generators MUST run in DP to prevent instantaneous blackout if 1 fails
        const share = Math.round(totalLoadkW / 4);
        activeGens[0] = share;
        activeGens[1] = share;
        activeGens[2] = share;
        activeGens[3] = share;
        rawGensOnlineCount = 4;
      } else if (currentParams.profile === "maneuver") {
        // 3 diesel generators online as precautions
        const share = Math.round(totalLoadkW / 3);
        activeGens[0] = share;
        activeGens[1] = share;
        activeGens[2] = share;
        rawGensOnlineCount = 3;
      } else {
        // Standard transit: G1 & G2 running constantly active
        const share = Math.round(totalLoadkW / 2);
        activeGens[0] = share;
        activeGens[1] = share;
        rawGensOnlineCount = 2;
      }

      // Conventional low-load operation drops efficiency to ~68-75% due to soot formation
      const averageLoadingPercent = (totalLoadkW / (rawGensOnlineCount * 1000)) * 100;
      if (averageLoadingPercent < 35) {
        dieselEfficiency = 65; // terrible low-load efficiency losses
      } else if (averageLoadingPercent < 60) {
        dieselEfficiency = 74;
      } else {
        dieselEfficiency = 78;
      }
    }

    // Redundancy shift if G1 failed
    if (faults.generator1Failure) {
      const g1Power = activeGens[0];
      if (g1Power > 0) {
        activeGens[0] = 0;
        let remaining = g1Power;
        
        // Push remaining to G2 first
        if (remaining > 0) {
          const spaceG2 = Math.max(0, maxG1G2 - activeGens[1]);
          const takeG2 = Math.min(spaceG2, remaining);
          activeGens[1] += takeG2;
          remaining -= takeG2;
        }
        // G3
        if (remaining > 0) {
          const spaceG3 = Math.max(0, maxG3G4 - activeGens[2]);
          const takeG3 = Math.min(spaceG3, remaining);
          activeGens[2] += takeG3;
          remaining -= takeG3;
        }
        // G4
        if (remaining > 0) {
          const spaceG4 = Math.max(0, maxG3G4 - activeGens[3]);
          const takeG4 = Math.min(spaceG4, remaining);
          activeGens[3] += takeG4;
          remaining -= takeG4;
        }
        
        // Hard overflow under damage
        if (remaining > 0) {
          activeGens[1] += Math.round(remaining / 3);
          activeGens[2] += Math.round(remaining / 3);
          activeGens[3] += Math.round(remaining / 3);
        }
      }
    }

    if (faults.busShortCircuit) {
      dieselEfficiency = Math.max(45, dieselEfficiency - 15);
    }

    rawGensOnlineCount = activeGens.filter(p => p > 0).length;

    // Fuel curves formulas L/h
    // Fuel Consumption = sum_of_active_gens( kW * fuelCurveCoeff * efficiencyFactor )
    // Conventional runs engines cold/inefficiently, AI optimizes.
    let baseFuelRate = 0;
    activeGens.forEach((power, idx) => {
      if (power > 0) {
        const coeff = VESSEL_SPECIFICATIONS.generators[idx].fuelCurveCoeff;
        const loadRatio = power / (idx < 2 ? maxG1G2 : maxG3G4);
        // Low load ratio increases specific fuel consumption
        const operationalCoeff = loadRatio < 0.35 ? 1.35 : loadRatio < 0.6 ? 1.15 : 1.02;
        baseFuelRate += power * coeff * operationalCoeff;
      }
    });

    // conventional overhead without batteries
    if (!currentParams.aiOptimized) {
      baseFuelRate = baseFuelRate * 1.25; // idle spin penalties
    }

    const finalFuelRate = Math.round(baseFuelRate);
    // CO2 emission equivalent (approx 2.65 kg CO2 per Liter of Marine Diesel burnt)
    const computedCO2Rate = Math.round(finalFuelRate * 2.64);

    return {
      hourTimestamp: hour,
      timeString: point.timeLabel,
      loadDemand: totalLoadkW,
      genPower: activeGens,
      batteryPower: batterykW,
      batterySoc: computedSoc,
      hotelLoad: hotelLoadkW,
      propulsionLoad: computedPropulsionkW,
      fuelFlowRate: finalFuelRate,
      co2FlowRate: computedCO2Rate,
      systemEfficiency: dieselEfficiency,
      activeGeneratorsCount: rawGensOnlineCount
    };
  };

  const activeTelemetry = getTelemetryData(selectedHour, params);

  // Active alarms computation
  const activeAlarms: { id: string; type: "critical" | "warning"; msg: string; system: string }[] = [];
  if (faults.generator1Failure) {
    activeAlarms.push({
      id: "err-g1",
      type: "critical",
      system: "PROPULSÃO / GERAÇÃO",
      msg: "Caterpillar G1 em falha mecânica severa (offline). Carga do navio redistribuída para G2/G3/G4."
    });
  }
  if (faults.batteryOverheat) {
    activeAlarms.push({
      id: "err-bat",
      type: "critical",
      system: "BANCO DE SÓDIO",
      msg: "Células com superaquecimento (>350 °C). Banco desconectado por proteção térmica bypass auto."
    });
  }
  if (faults.aiCommunicationLoss) {
    activeAlarms.push({
      id: "err-ai",
      type: "warning",
      system: "DADOS LSTM",
      msg: "Sinal de IA fora do ar. Sem contato com rede predictiva; operando com controle manual convencional."
    });
  }
  if (faults.busShortCircuit) {
    activeAlarms.push({
      id: "err-bus",
      type: "critical",
      system: "BARRAMENTO PRINCIPAL",
      msg: "Curto-circuito resistivo simulado. Queda de tensão compensada com +500kW e perda de rendimento."
    });
  }
  if (activeTelemetry.loadDemand > 3500) {
    activeAlarms.push({
      id: "warn-load",
      type: "warning",
      system: "SOBRECARGA",
      msg: `Barramento em regime de sobrecarga severo (${activeTelemetry.loadDemand} kW). Estresse elétrico geral.`
    });
  }
  if (params.seaStateBeaufort >= 5) {
    activeAlarms.push({
      id: "warn-sea",
      type: "warning",
      system: "CONDIÇÕES SEVERAS",
      msg: `Mar Beaufort nível ${params.seaStateBeaufort}: arrasto dinâmico amplificado.`
    });
  }

  // Dynamic Battery Calculations
  const parsedVoltage = parseInt(params.batteryVoltage) || 125;
  // Total Bank Capacity in kWh = (Count * Voltage * Amperage) / 1000
  const totalBatteryKWh = (params.batteryCount * parsedVoltage * params.batteryAmperage) / 1000;
  const dynamicCapacityLabel = totalBatteryKWh >= 1000
    ? `${(totalBatteryKWh / 1000).toFixed(2)} MWh`
    : `${totalBatteryKWh.toLocaleString()} kWh`;
  const totalBankAmperage = params.batteryCount * params.batteryAmperage;

  // Generate 24h stats for comparative analysis panels
  const getComparativeData = (): ComparativeMetrics => {
    let convFuelSum = 0;
    let convCo2Sum = 0;
    let convEffSum = 0;

    let aiFuelSum = 0;
    let aiCo2Sum = 0;
    let aiEffSum = 0;

    for (let h = 0; h < 24; h++) {
      const conv = getTelemetryData(h, { ...params, aiOptimized: false });
      const ai = getTelemetryData(h, { ...params, aiOptimized: true });

      convFuelSum += conv.fuelFlowRate;
      convCo2Sum += conv.co2FlowRate;
      convEffSum += conv.systemEfficiency;

      aiFuelSum += ai.fuelFlowRate;
      aiCo2Sum += ai.co2FlowRate;
      aiEffSum += ai.systemEfficiency;
    }

    const convFuelTotal = Math.round(convFuelSum);
    const convCo2Total = Math.round(convCo2Sum);
    const convAvgEff = Math.round(convEffSum / 24);

    const aiFuelTotal = Math.round(aiFuelSum);
    const aiCo2Total = Math.round(aiCo2Sum);
    const aiAvgEff = Math.round(aiEffSum / 24);

    const fuelSavings = Math.round(((convFuelTotal - aiFuelTotal) / convFuelTotal) * 100);
    const co2Savings = Math.round(((convCo2Total - aiCo2Total) / convCo2Total) * 100);
    const effGain = aiAvgEff - convAvgEff;

    // Lithium technology calculations (typically ~65% of the savings of optimized Safe Sodium-Nickel batteries due to active safety buffers/cooling)
    const lithFuelTotal = Math.round(convFuelTotal - (convFuelTotal - aiFuelTotal) * 0.65);
    const lithCo2Total = Math.round(convCo2Total - (convCo2Total - aiCo2Total) * 0.65);
    const lithAvgEff = Math.round(convAvgEff + (aiAvgEff - convAvgEff) * 0.65);
    const lithFuelSavings = Math.round(((convFuelTotal - lithFuelTotal) / convFuelTotal) * 100);
    const lithCo2Savings = Math.round(((convCo2Total - lithCo2Total) / convCo2Total) * 100);
    const lithEffGain = lithAvgEff - convAvgEff;

    return {
      conventional: {
        fuelTotal: convFuelTotal,
        co2Total: convCo2Total,
        avgEfficiency: convAvgEff,
        blackoutRisks: params.profile === "dp" ? 1 : 0 // DP has blackout risk manually scheduled without batteries
      },
      hybridLithium: {
        fuelTotal: lithFuelTotal,
        co2Total: lithCo2Total,
        avgEfficiency: lithAvgEff,
        fuelSavingsPercent: lithFuelSavings,
        co2SavingsPercent: lithCo2Savings,
        efficiencyGainPp: lithEffGain,
        blackoutRisks: 1 // LFP/NMC has moderate risks under extreme DP conditions
      },
      hybridAi: {
        fuelTotal: aiFuelTotal,
        co2Total: aiCo2Total,
        avgEfficiency: aiAvgEff,
        fuelSavingsPercent: fuelSavings,
        co2SavingsPercent: co2Savings,
        efficiencyGainPp: effGain,
        blackoutRisks: 0 // Sodium Battery provides instantaneous redundant buffer (0 risk)
      }
    };
  };

  const summaryMetrics = getComparativeData();

  // Strip headings hashtags and bold marks from assistant responses
  const sanitizeResponseText = (text: string): string => {
    if (!text) return "";
    let clean = text;
    // Remove all double asterisks (bold)
    clean = clean.replace(/\*\*/g, "");
    // Remove all single asterisks (italics/bold leftover)
    clean = clean.replace(/\*/g, "");
    // Remove all hashtags (jogo da velha) for headings while keeping the text intact
    clean = clean.replace(/#+/g, "");
    return clean;
  };

  // Dynamic telemetry backup responder to answer Carbon and System Energy questions when satellite links fail or Gemini is not configured
  const generateLocalTelemetryAnswer = (queryText: string, telemetry: any, metrics: any) => {
    const query = queryText.toLowerCase().trim();
    
    // Carbon / Emissions / CO2 / Fuel / Savings keywords in PT-BR
    const isCarbon = query.includes("carbon") || 
                     query.includes("co2") || 
                     query.includes("emiss") || 
                     query.includes("verde") || 
                     query.includes("meio ambiente") || 
                     query.includes("sustent") || 
                     query.includes("polu") ||
                     query.includes("clima") ||
                     query.includes("combust") ||
                     query.includes("diesel") ||
                     query.includes("óleo") ||
                     query.includes("oleo") ||
                     query.includes("econom") ||
                     query.includes("convencional");
    
    // Energy / Batteries / Generators / Power / Volts / Amperes / LSTM / MPC keywords in PT-BR
    const isEnergy = query.includes("energ") || 
                     query.includes("bater") || 
                     query.includes("sod") || 
                     query.includes("sonio") || 
                     query.includes("litio") || 
                     query.includes("lítio") || 
                     query.includes("motor") || 
                     query.includes("gerad") || 
                     query.includes("kw") || 
                     query.includes("mwh") || 
                     query.includes("kwh") || 
                     query.includes("carreg") || 
                     query.includes("descarreg") || 
                     query.includes("voltag") || 
                     query.includes("amper") || 
                     query.includes("mpc") || 
                     query.includes("lstm") || 
                     query.includes("propuls") ||
                     query.includes("tensão") ||
                     query.includes("corrente");

    if (!isCarbon && !isEnergy) {
      return null;
    }

    let text = "";

    if (isCarbon && isEnergy) {
      text += `RELATORIO INTEGRADO: BALANÇO DINAMICO DE EMISSÕES E MATRIZ ENERGETICA

Análise de telemetria em tempo real para a embarcação PSV World Diamond no perfil ${telemetry.profile || "Transit"}.

1. EMISSÕES DE CARBONO E CONSUMO DE DIESEL:
- Taxa Estática de CO2 Atual: ${(telemetry.co2FlowRate || 0).toFixed(1)} kg / hora (decorrente de um consumo de ${(telemetry.fuelFlowRate || 0).toFixed(1)} L/h).
- Projeção Global Comparativa (Consumo e Emissões de CO2 acumulados em 24h):
  * Sistema Convencional (Diesel-Elétrico Puro):
    * Consumo: ${(metrics.conventional.fuelTotal || 0).toLocaleString()} Litros
    * CO2 Total: ${(metrics.conventional.co2Total || 0).toLocaleString()} kg
    * Eficiência Térmica: ${metrics.conventional.avgEfficiency || 0}%
  * Híbrido com Bateria de Ions de Sódio (Inteligente LSTM + MPC):
    * Consumo: ${(metrics.hybridAi.fuelTotal || 0).toLocaleString()} Litros (Economia de ${metrics.hybridAi.fuelSavingsPercent || 0}%)
    * CO2 Total: ${(metrics.hybridAi.co2Total || 0).toLocaleString()} kg (Redução de ${metrics.hybridAi.co2SavingsPercent || 0}%)
    * Eficiência Térmica: ${metrics.hybridAi.avgEfficiency || 0}%

2. FLUXO E DESEMPENHO ENERGETICO DAS BATERIAS:
- Demanda Elétrica Total: ${(telemetry.loadDemand || 0).toLocaleString()} kW (${(telemetry.propulsionLoad || 0).toLocaleString()} kW em Propulsores e ${(telemetry.hotelLoad || 0).toLocaleString()} kW em Hotelaria/Cargas Auxiliares).
- Estado de Carga (SOC) Atual: ${telemetry.batterySoc || 0}%
- Atividade Química do Banco de Sódio:
  * Ions de Sódio: Seguridade contra fuga térmica, isentas de risco de fogo ou sobreaquecimento agressivo em altas temperaturas tropicais marinhas. Fluxo atual: ${telemetry.batteryPower === 0 ? "0 kW (Standby)" : telemetry.batteryPower > 0 ? `${telemetry.batteryPower} kW (Atuando como backup em DP)` : `${Math.abs(telemetry.batteryPower)} kW (Recarregamento ativo via excedente de alternadores)`}

3. CONTROLE PREDITIVO BASEADO EM IA:
- O controle inteligente LSTM + MPC prevê picos de arrasto em ondas com 15 minutos de antecedência usando LSTM, otimizando o acionamento de geradores via controle preditivo MPC. Isso garante que geradores Caterpillar trabalhem apenas em sua faixa ótima de eficiência termodinâmica (${telemetry.aiOptimized ? "ATIVO" : "DESATIVADO"}).`;
    } else if (isCarbon) {
      text += `RELATORIO DE EMISSÕES DE CARBONO E SUSTENTABILIDADE NAVAL

Análise dedicada de descarbonização em relação à operação convencional e híbrida do PSV World Diamond.

1. TELEMETRIA E CONSUMO INSTANTÂNEO:
- Consumo de Óleo Diesel Atual: ${(telemetry.fuelFlowRate || 0).toFixed(1)} Litros/hora
- Taxa de Emissões de CO2 Atual: ${(telemetry.co2FlowRate || 0).toFixed(1)} kg/hora

2. BALANÇO OPERATIVO COMPARATIVO DE ECONOMIA (CICLO DE 24 HORAS):
- Convencional (Sem Bateria, Diesel-Elétrico Puro):
  * Consumo Total: ${(metrics.conventional.fuelTotal || 0).toLocaleString()} L
  * CO2 Total Emitido: ${(metrics.conventional.co2Total || 0).toLocaleString()} kg
- Híbrido Inteligente com Bateria de Ions de Sódio (LSTM + MPC):
  * Consumo Total: ${(metrics.hybridAi.fuelTotal || 0).toLocaleString()} L
  * CO2 Total Emitido: ${(metrics.hybridAi.co2Total || 0).toLocaleString()} kg
  * Economia Realizada: -${metrics.hybridAi.fuelSavingsPercent || 0}% em Combustível / -${metrics.hybridAi.co2SavingsPercent || 0}% em Carbono

3. IMPACTO OPERACIONAL E DIRETRIZES IMO 2030 / 2050:
- O uso de baterias de sódio de vácuo térmico operadas com LSTM + MPC permite a redução imediata da pegada de carbono, extinguindo a necessidade de múltiplos geradores ligados sem real utilidade em DP, mitigando os picos transientes e operando sem risco de fogo catastrófico.`;
    } else if (isEnergy) {
      text += `MATRIZ ENERGETICA, ARMAZENAMENTO E GERAÇÃO

Acompanhamento dinâmico do comportamento de energia da embarcação PSV World Diamond.

1. DISTRIBUIÇÃO DE CARGA ELÉTRICA ATUAL:
- Carga Total da Rede Integrada: ${(telemetry.loadDemand || 0).toLocaleString()} kW
  * Consumo dos Propulsores Azimutais: ${(telemetry.propulsionLoad || 0).toLocaleString()} kW
  * Consumo Hidráulico / Hotelaria Auxiliar: ${(telemetry.hotelLoad || 0).toLocaleString()} kW
- Distribuição de Carga entre Geradores:
  * Motores online: ${telemetry.activeGeneratorsCount} de 4.
  * Barramento individual: G1: ${telemetry.genPower[0] || 0} kW | G2: ${telemetry.genPower[1] || 0} kW | G3: ${telemetry.genPower[2] || 0} kW | G4: ${telemetry.genPower[3] || 0} kW.

2. TECNOLOGIAS DE ARMAZENAMENTO DE ENERGIA:
- Banco de Baterias de Ions de Sódio (LSTM + MPC):
  * Capacidade Estocada: 2 MWh operando em alta tensão elétrica para neutralizar transientes.
  * Estado de Carga (SOC): ${telemetry.batterySoc || 0}%
  * Fluxo de Potência instantâneo: ${telemetry.batteryPower === 0 ? "0 kW (Standby)" : telemetry.batteryPower > 0 ? `${telemetry.batteryPower} kW (DESCARREGANDO - Peak Shaving)` : `${Math.abs(telemetry.batteryPower)} kW (CARREGANDO)`}
  * Eficiência Operativa Global: ${telemetry.systemEfficiency || 0}% (Ganho substancial via gerenciamento autônomo).

3. FILOSOFIA DO SISTEMA LSTM + MPC:
- Utiliza a rede neural LSTM para previsões de arrasto com horizonte de 15 minutos, regulando as rampas dos geradores principais, mantendo o barramento estabilizado continuamente e permitindo que as baterias de sódio de 125Vcc absorvam os transientes repentinos das ondas em milissegundos.`;
    }

    return text;
  };

  // Send request to server-side Gemini Adviser API
  const handleSendAdvisoryQuery = async (queryText: string) => {
    if (!queryText.trim()) return;

    const userMsg: AiAdvisoryMessage = {
      role: "user",
      content: queryText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setAdvisoryMessages(prev => [...prev, userMsg]);
    setUserQuery("");
    setAiLoading(true);

    // Intercept preset questions to show expert answers instantly and beautifully
    if (PRESETS_ANSWERS[queryText]) {
      setTimeout(() => {
        setAdvisoryMessages(prev => [
          ...prev,
          {
            role: "assistant",
            content: PRESETS_ANSWERS[queryText],
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
        setAiLoading(false);
      }, 750);
      return;
    }

    try {
      const response = await fetch("/api/ai-advisory", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          message: queryText,
          telemetry: {
            profile: params.profile.toUpperCase(),
            vesselSpeed: params.vesselSpeed,
            seaState: params.seaStateBeaufort,
            loadDemand: activeTelemetry.loadDemand,
            hotelLoad: activeTelemetry.hotelLoad,
            propulsionLoad: activeTelemetry.propulsionLoad,
            activeGeneratorsCount: activeTelemetry.activeGeneratorsCount,
            genPower: activeTelemetry.genPower,
            batteryVoltage: params.batteryVoltage,
            batteryCount: params.batteryCount,
            batteryAmperage: params.batteryAmperage,
            batteryCapacityKWh: totalBatteryKWh,
            batterySoc: activeTelemetry.batterySoc,
            batteryPower: activeTelemetry.batteryPower,
            fuelFlowRate: activeTelemetry.fuelFlowRate,
            co2FlowRate: activeTelemetry.co2FlowRate,
            systemEfficiency: activeTelemetry.systemEfficiency,
            aiOptimized: params.aiOptimized
          }
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "Erro obtendo resposta da IA.");
      }

      setAdvisoryMessages(prev => [
        ...prev,
        {
          role: "assistant",
          content: data.text,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (e: any) {
      console.error(e);
      
      const payloadTelemetry = {
        profile: params.profile.toUpperCase(),
        vesselSpeed: params.vesselSpeed,
        seaState: params.seaStateBeaufort,
        loadDemand: activeTelemetry.loadDemand,
        hotelLoad: activeTelemetry.hotelLoad,
        propulsionLoad: activeTelemetry.propulsionLoad,
        activeGeneratorsCount: activeTelemetry.activeGeneratorsCount,
        genPower: activeTelemetry.genPower,
        batteryVoltage: params.batteryVoltage,
        batteryCount: params.batteryCount,
        batteryAmperage: params.batteryAmperage,
        batteryCapacityKWh: totalBatteryKWh,
        batterySoc: activeTelemetry.batterySoc,
        batteryPower: activeTelemetry.batteryPower,
        fuelFlowRate: activeTelemetry.fuelFlowRate,
        co2FlowRate: activeTelemetry.co2FlowRate,
        systemEfficiency: activeTelemetry.systemEfficiency,
        aiOptimized: params.aiOptimized
      };

      const localAnswer = generateLocalTelemetryAnswer(queryText, payloadTelemetry, summaryMetrics);
      
      if (localAnswer) {
        setAdvisoryMessages(prev => [
          ...prev,
          {
            role: "assistant",
            content: `📡 [SISTEMA AUTÔNOMO DE TELEMETRIA NAVAL - LINK DE BACKUP]\n\nConexão satélite instável no mar. Computador de bordo resolveu a consulta processando dados reais dos sensores do navio:\n\n${localAnswer}`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      } else {
        setAdvisoryMessages(prev => [
          ...prev,
          {
            role: "assistant",
            content: `⚠️ Aviso de Falha no Link de Satélite (Gemini API): \n\n${e.message || "Erro de conexão."}. Por favor, verifique se a sua chave do Gemini já está configurada nas configurações seguras da plataforma e tente novamente!`,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      }
    } finally {
      setAiLoading(false);
    }
  };

  // Preset question triggers
  const handlePresetTrigger = (presetQuery: string) => {
    handleSendAdvisoryQuery(presetQuery);
  };

  // Format power to be easy readable
  const formatkW = (kw: number) => {
    return `${kw.toLocaleString()} kW`;
  };

  return (
    <div className="flex flex-col min-h-screen bg-green-dark text-[#e2e8f0] font-sans antialiased overflow-x-hidden selection:bg-green-highlight selection:text-black">
      
      {/* GLOWING AMBIENCE BACKDROPS - GREEN PALETTE ONLY */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[350px] bg-green-highlight/10 rounded-full blur-[150px] pointer-events-none -z-10" />
      <div className="absolute top-1/2 right-1/4 w-[400px] h-[400px] bg-green-accent/10 rounded-full blur-[160px] pointer-events-none -z-10" />

      {/* TOP SCI-FI COCKPIT BANNER */}
      <header className="border-b border-green-border/40 bg-green-dark/95 backdrop-blur-md px-6 py-4 sticky top-0 z-40 shadow-[0_1px_15px_rgba(77,112,25,0.02)]">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          
          {/* Logo & Operational State */}
          <div className="flex items-center gap-3.5">
            <div className="relative flex items-center justify-center w-11 h-11 bg-green-panel border border-green-highlight/50 rounded-none shadow-[0_0_12px_rgba(118,153,61,0.15)] overflow-hidden">
              <Ship className="w-6 h-6 text-green-highlight" />
              <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-green-highlight" />
              <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-green-highlight" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-display font-medium tracking-tight text-white text-sm md:text-base leading-tight max-w-3xl">
                  Arquitetura Inteligente de Gerenciamento Energético (Sódio/IA)
                </h1>
                <span className="hidden sm:inline-flex items-center px-1.5 py-0.5 text-[8.5px] font-mono tracking-widest text-[#22300B] bg-green-highlight uppercase whitespace-nowrap">
                  Vessel No.3300 • PRÉ-SAL
                </span>
              </div>
              <p className="text-[10px] text-zinc-500 font-mono tracking-wider uppercase flex items-center gap-1.5 mt-0.5">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-highlight opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-accent"></span>
                </span>
                SISTEMA NAVAL DE GERENCIAMENTO ENERGÉTICO • ATIVO
              </p>
            </div>
          </div>

          {/* Quick Realtime Specs Dashboard */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-6 text-xs font-mono bg-green-panel/85 border border-green-border/35 px-4 py-2">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-green-highlight" />
              <div>
                <span className="block text-[9px] text-zinc-500 uppercase leading-none">Embarcação</span>
                <span className="text-slate-100 font-bold">PSV WORLD DIAMOND</span>
              </div>
            </div>
            
            <div className="h-6 w-[1px] bg-green-border/45 hidden sm:block" />

            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-green-highlight" />
              <div>
                <span className="block text-[9px] text-zinc-500 uppercase leading-none">Bateria</span>
                <span className="text-green-highlight font-bold uppercase">{dynamicCapacityLabel}</span>
              </div>
            </div>

            <div className="h-6 w-[1px] bg-green-border/45 hidden sm:block" />

            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-green-highlight" />
              <div>
                <span className="block text-[9px] text-zinc-500 uppercase leading-none">Simulado</span>
                <span className="text-slate-200 font-bold">24 Horas Ativas</span>
              </div>
            </div>
          </div>

        </div>
      </header>

      {/* SUB-HEADER BRAND COCKPIT */}
      <section className="bg-gradient-to-r from-[#003d1c]/20 via-green-dark to-[#002311] border-b border-green-border/25 px-6 py-3 text-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 text-slate-300 font-mono text-[11px]">
          <div className="flex items-center gap-2">
            <span className={`border px-1 py-0.25 text-[9px] uppercase font-bold tracking-wide ${
              faults.aiCommunicationLoss 
                ? "border-rose-500/50 text-rose-400 bg-rose-950/40 animate-pulse" 
                : "border-green-highlight/40 text-green-highlight"
            }`}>
              {faults.aiCommunicationLoss ? "SINAL OFFLINE" : "ALGORITMO IA"}
            </span>
            <span className={faults.aiCommunicationLoss ? "text-rose-400 font-bold" : "text-slate-300"}>
              {faults.aiCommunicationLoss 
                ? "Falha de Link de Dados: Fallback para Controle Convencional" 
                : "LSTM (Previsão de Carga 15min) + MPC (Model Predictive Control 1min)"
              }
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span>VOLT EXIGIDO: <strong className="text-green-highlight">{params.batteryVoltage}</strong></span>
            <span className="text-zinc-600">|</span>
            <span>EFICIÊNCIA GLOBAL: <strong className={faults.busShortCircuit ? "text-rose-455 font-bold" : "text-green-highlight"}>{activeTelemetry.systemEfficiency}%</strong></span>
          </div>
        </div>
      </section>

      {/* CORE FRAME LAYOUT */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">

        {/* TABS SELECTOR FOR SPECIFIC VIEWS */}
        <div className="flex border-b border-green-border/30 text-xs font-mono flex-wrap">
          <button
            onClick={() => setActiveTab("telemetry")}
            className={`px-5 py-3 transition uppercase tracking-widest font-bold border-b-2 ${
              activeTab === "telemetry"
                ? "border-green-highlight text-white bg-green-panel/40"
                : "border-transparent text-zinc-400 hover:text-white"
            }`}
          >
            Monitor de Telemetria & Controle
          </button>
          <button
            onClick={() => setActiveTab("battery")}
            className={`px-5 py-3 transition uppercase tracking-widest font-bold border-b-2 ${
              activeTab === "battery"
                ? "border-green-highlight text-white bg-green-panel/40"
                : "border-transparent text-zinc-400 hover:text-white"
            }`}
          >
            Ficha das Baterias de Sódio
          </button>
          <button
            onClick={() => setActiveTab("comparison")}
            className={`px-5 py-3 transition uppercase tracking-widest font-bold border-b-2 ${
              activeTab === "comparison"
                ? "border-green-highlight text-white bg-green-panel/40"
                : "border-transparent text-zinc-400 hover:text-white"
            }`}
          >
            Balanço e Reduções 24h
          </button>
          <button
            onClick={() => setActiveTab("faq")}
            className={`px-5 py-3 transition uppercase tracking-widest font-bold border-b-2 ${
              activeTab === "faq"
                ? "border-green-highlight text-white bg-green-panel/40"
                : "border-transparent text-zinc-400 hover:text-white"
            }`}
          >
            Respostas das Perguntas (FAQ)
          </button>
        </div>

        {/* METRICS & PARAMETERS GRID PANEL */}
        {activeTab === "telemetry" && (
          <>
            {/* REFERENT SPECIFICATIONS BANNER */}
            <div className="grid grid-cols-1 lg:grid-cols-4 border border-green-border/40 bg-green-panel shadow-[0_4px_25px_rgba(0,0,0,0.5)] mb-6">
              <div className="lg:col-span-3 p-5 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-green-border/40 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-green-highlight/5 rotate-45 translate-x-12 -translate-y-12 rounded-full blur-2xl pointer-events-none" />
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="p-1 text-green-highlight bg-green-panel/50 border border-green-border/30">
                      <Anchor className="w-4 h-4" />
                    </span>
                    <span className="text-[10px] uppercase font-mono tracking-widest text-green-highlight">Embarcação PSV Referência</span>
                  </div>
                  <h2 className="font-display font-medium text-xl md:text-2xl text-white tracking-tight uppercase">
                    PSV World Diamond
                  </h2>
                  <p className="text-xs text-zinc-400 font-mono mt-1">
                    Design Damen PSV 3300 • Apoio à cadeia produtiva offshore do Pré-Sal brasileiro.
                  </p>
                  
                  {/* Ship attributes list */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 text-xs font-mono">
                    <div className="bg-green-dark/40 p-2.5 border border-green-border/30">
                      <span className="block text-[9px] text-[#52525b] uppercase leading-none mb-1">Comprimento</span>
                      <span className="text-slate-200 font-bold">{VESSEL_SPECIFICATIONS.length}</span>
                    </div>
                    <div className="bg-green-dark/40 p-2.5 border border-green-border/30">
                      <span className="block text-[9px] text-[#52525b] uppercase leading-none mb-1">Boca (Largura)</span>
                      <span className="text-slate-200 font-bold">{VESSEL_SPECIFICATIONS.beam}</span>
                    </div>
                    <div className="bg-green-dark/40 p-2.5 border border-green-border/30">
                      <span className="block text-[9px] text-[#52525b] uppercase leading-none mb-1">Porte Bruto</span>
                      <span className="text-slate-200 font-bold">{VESSEL_SPECIFICATIONS.deadweight}</span>
                    </div>
                    <div className="bg-green-dark/40 p-2.5 border border-green-border/30">
                      <span className="block text-[9px] text-[#52525b] uppercase leading-none mb-1">Potência Total</span>
                      <span className="text-green-highlight font-bold">{VESSEL_SPECIFICATIONS.totalInstalledPower}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-5 pt-4 border-t border-green-border/25 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-zinc-400 font-mono">
                  <span className="flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-green-accent" />
                    Propulsão: Diesel-Elétrica Híbrida Inteligente
                  </span>
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-green-accent" />
                    Redução de combustível de até 40% em DP com MPC
                  </span>
                </div>
              </div>

               {/* QUICK CHASSIS RENDERING - SODIUM BATTERY GRAPHIC */}
              <div className="p-5 bg-gradient-to-b from-green-panel to-green-dark flex flex-col justify-between relative border-t lg:border-t-0 border-green-border/30">
                <div className="absolute top-2 right-2 flex items-center gap-1.5">
                  <span className={`inline-block w-2.5 h-2.5 rounded-full ${faults.batteryOverheat ? "bg-rose-500 animate-ping" : "bg-green-highlight animate-pulse"}`} />
                  <span className={`text-[8px] font-mono tracking-widest uppercase ${faults.batteryOverheat ? "text-rose-500 font-bold" : "text-green-highlight"}`}>
                    {faults.batteryOverheat ? "Bypass Ativo" : "Sódio Ativo"}
                  </span>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] uppercase font-mono tracking-widest text-[#a1a1aa]">BANCO DE BATERIAS ({params.batteryCount} un. / {params.batteryAmperage} A)</span>
                  </div>
                  
                  {/* Renderized simulated sodium battery chassis */}
                   <div className={`border p-3 relative select-none transition-colors duration-305 ${
                     faults.batteryOverheat 
                       ? "border-rose-900/50 bg-[#14060b] shadow-[0_0_15px_rgba(244,63,94,0.06)]" 
                       : "border-green-border/55 bg-green-panel shadow-[0_0_15px_rgba(0,133,66,0.05)]"
                   }`}>
                     <div className={`text-[8px] font-mono tracking-widest flex justify-between uppercase mb-1 ${faults.batteryOverheat ? "text-rose-400 font-bold" : "text-green-highlight"}`}>
                       <span>TEMPERATURA CELULAR</span>
                       <span className="flex items-center gap-0.5">
                         <Thermometer className="w-2.5 h-2.5" /> 
                         {faults.batteryOverheat ? "365 °C (CRÍTICO)" : "275 °C"}
                       </span>
                     </div>
                     <div className={`h-10 border rounded-none flex items-center justify-between px-3 mb-2 relative overflow-hidden ${
                       faults.batteryOverheat ? "bg-[#110508] border-rose-950" : "bg-green-dark border-green-border/30"
                     }`}>
                       {/* Sodium metal cell representation */}
                       <div className={`absolute inset-y-0 left-0 transition-all ${
                         faults.batteryOverheat ? "bg-rose-500/10 w-0 border-r-0" : "bg-green-highlight/10 w-[78%] border-r border-green-highlight/30"
                       }`} />
                       <div className="flex items-baseline relative z-10 font-mono">
                         <span className="text-white text-base font-bold">{faults.batteryOverheat ? "0" : parsedVoltage}</span>
                         <span className="text-zinc-500 text-[10px] ml-0.5">Vcc</span>
                       </div>
                       <div className={`text-[10px] font-mono font-bold relative z-10 ${faults.batteryOverheat ? "text-rose-500" : "text-green-highlight"}`}>
                         {faults.batteryOverheat ? "ISOLADO" : "78% SOC"}
                       </div>
                     </div>
                     <div className="flex items-center justify-between text-[8px] text-[#52525b] font-mono leading-none">
                       <span>SÓDIO-METAL TECH</span>
                       <span className={`border px-1 text-[7px] font-bold ${faults.batteryOverheat ? "border-rose-900 text-rose-500" : "border-green-border text-green-accent"}`}>
                         {faults.batteryOverheat ? "SAFETY SHUTDOWN" : "INMETRO"}
                       </span>
                     </div>
                   </div>
 
                   <p className="text-[10px] text-zinc-400 font-mono leading-relaxed pt-1">
                     Banco com {params.batteryCount} acumuladores de {parsedVoltage}Vcc e capacidade individual de {params.batteryAmperage} A. Potência total calculada: <span className="text-green-highlight font-bold">{dynamicCapacityLabel}</span>.
                   </p>
                 </div>
 
                 <button
                   onClick={() => setActiveTab("battery")}
                   className="mt-4 py-1.5 w-full bg-green-dark hover:bg-green-panel border border-green-highlight/45 text-green-highlight text-[10px] font-mono font-bold tracking-widest uppercase transition rounded-none text-center cursor-pointer"
                 >
                  Ficha Técnica do Sódio
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* COLUMN 1: INTERACTIVE OPERATIONAL CONTROLS (4 SPAN) */}
            <div className="lg:col-span-4 space-y-6">
              
              <div className="border border-green-border/40 bg-green-panel p-5">
                <div className="flex items-center gap-2 mb-4 pb-2 border-b border-green-border/25">
                  <Cpu className="w-5 h-5 text-green-highlight" />
                  <h3 className="font-mono text-xs uppercase text-white font-bold tracking-wider">
                    Filtros de Simulação
                  </h3>
                </div>

                {/* AI SWITCH CHANGER */}
                <div className="mb-5 bg-green-dark border border-green-border/30 p-3.5 flex flex-col space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-mono text-zinc-300 font-bold uppercase tracking-wide">
                      Gerenciamento por IA
                    </span>
                    <span className={`px-2 py-0.5 text-[8.5px] font-mono leading-none font-bold uppercase border ${
                      faults.aiCommunicationLoss
                        ? "bg-rose-950/40 border-rose-500/40 text-rose-400"
                        : params.aiOptimized 
                          ? "bg-green-panel/50 border border-green-highlight/50 text-green-highlight font-bold" 
                          : "bg-zinc-800 border border-zinc-700 text-zinc-400"
                    }`}>
                      {faults.aiCommunicationLoss 
                        ? "SEM SINAL (MANUAL)" 
                        : params.aiOptimized ? "LSTM + MPC ATIVO" : "TRADICIONAL (MANUAL)"}
                    </span>
                  </div>
                  <p className="text-[10px] text-zinc-500 font-mono leading-normal leading-snug">
                     O controle inteligente AI prevê picos de arrasto em ondas de curto prazo usando LSTM, otimizando o acionamento de geradores via preditivo MPC.
                  </p>
                  <button
                    onClick={() => {
                      if (!faults.aiCommunicationLoss) {
                        setParams(prev => ({ ...prev, aiOptimized: !prev.aiOptimized }));
                      }
                    }}
                    disabled={faults.aiCommunicationLoss}
                    className={`mt-2 py-2 w-full text-[10px] font-mono uppercase tracking-widest font-bold transition flex items-center justify-center gap-2 border cursor-pointer ${
                      faults.aiCommunicationLoss
                        ? "bg-zinc-900 border-zinc-800 text-zinc-500 cursor-not-allowed opacity-50"
                        : params.aiOptimized
                          ? "bg-green-highlight hover:bg-green-highlight/85 text-green-dark border-green-highlight"
                          : "bg-green-panel hover:bg-green-panel/80 text-zinc-300 border-green-border"
                    }`}
                  >
                    <Power className="w-3.5 h-3.5" />
                    {faults.aiCommunicationLoss 
                      ? "Sinal Fora de Alcance" 
                      : params.aiOptimized ? "Desativar Algoritmo de IA" : "Ativar Otimização Inteligente"}
                  </button>
                </div>

                {/* Profile selects */}
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] tracking-wider text-zinc-400 font-mono uppercase font-bold">
                      Perfil Operacional Ativo
                    </label>
                    <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
                      {(["port", "transit", "dp", "maneuver"] as OperationalProfile[]).map((p) => {
                        const labels: Record<OperationalProfile, string> = {
                          port: "Porto & Carga",
                          transit: "Transit (12 nós)",
                          dp: "DP offshore",
                          maneuver: "Manobras / Porto"
                        };
                        const isActive = params.profile === p;
                        return (
                          <button
                            key={p}
                            onClick={() => handleProfileChange(p)}
                            className={`py-2 px-1 text-center transition tracking-wide font-bold uppercase cursor-pointer ${
                              isActive
                                ? "bg-green-panel text-green-highlight border border-green-highlight/50 shadow-[0_0_10px_rgba(255,209,0,0.15)]"
                                : "bg-green-dark border border-green-border/20 text-zinc-400 hover:text-white"
                            }`}
                          >
                            {labels[p]}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div className="h-[1px] bg-green-border/20 my-2" />

                  {/* Speed sliders */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-zinc-400 uppercase font-bold text-[10px]">Velocidade do Navio</span>
                      <span className="text-green-highlight font-bold">{params.vesselSpeed} nós</span>
                    </div>
                    <input
                      type="range"
                      min={params.profile === "port" ? 0 : 2}
                      max={params.profile === "port" ? 0 : 13}
                      step="1"
                      value={params.vesselSpeed}
                      onChange={(e) => {
                        const val = parseInt(e.target.value);
                        setParams(prev => ({ ...prev, vesselSpeed: val > 13 ? 13 : val }));
                      }}
                      disabled={params.profile === "port"}
                      className="w-full h-1 bg-green-dark border border-green-border/30 rounded-lg appearance-none cursor-pointer accent-green-highlight disabled:opacity-50"
                    />
                    <span className="text-[9px] text-[#52525b] font-mono block leading-none">
                      O arrasto cresce quadraticamente com a velocidade (máximo limitado pela IA a 13 nós para não exceder a curva simuladora operacional segura).
                    </span>
                  </div>

                  {/* Wave sliders (Beaufort scale) */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-zinc-400 uppercase font-bold text-[10px]">Estado do Mar (Beaufort)</span>
                      <span className="text-green-highlight font-bold">Mar {params.seaStateBeaufort}</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="6"
                      step="1"
                      value={params.seaStateBeaufort}
                      onChange={(e) => setParams(prev => ({ ...prev, seaStateBeaufort: parseInt(e.target.value) }))}
                      className="w-full h-1 bg-green-dark border border-green-border/30 rounded-lg appearance-none cursor-pointer accent-green-highlight"
                    />
                    <div className="flex justify-between text-[9px] text-zinc-500 font-mono">
                      <span>Calmo (1)</span>
                      <span>Médio (3)</span>
                      <span>Mar Agitado (6)</span>
                    </div>
                  </div>

                  {/* Hotel Load sliders */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="text-zinc-400 uppercase font-bold text-[10px]">Carga de Hotelaria</span>
                      <span className="text-green-highlight font-bold">{params.hotelLoadSetting} kW</span>
                    </div>
                    <input
                      type="range"
                      min="150"
                      max="5000"
                      step="50"
                      value={params.hotelLoadSetting}
                      onChange={(e) => setParams(prev => ({ ...prev, hotelLoadSetting: parseInt(e.target.value) }))}
                      className="w-full h-1 bg-green-dark border border-green-border/30 rounded-lg appearance-none cursor-pointer accent-green-highlight"
                    />
                    <span className="text-[9px] text-[#52525b] font-mono block leading-none">
                      Requisitos elétricos fixos para iluminação, bombas, perfuração e suporte.
                    </span>
                  </div>

                  {/* Volt Switch selector */}
                  <div className="space-y-2 pt-2 border-t border-green-border/20">
                    <label className="text-[10px] tracking-wider text-zinc-400 font-mono uppercase font-bold block mb-1">
                      Tensão do Banco de Sódio
                    </label>
                    <div className="bg-green-panel border border-green-border/25 text-green-highlight py-2 px-3 text-center transition font-bold font-mono text-[10px]">
                      125Vcc (Padrão de Alta Tensão)
                    </div>
                  </div>

                  {/* Battery count and amperage controllers */}
                  <div className="space-y-4 pt-2 border-t border-green-border/20">
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs font-mono">
                        <span className="text-zinc-400 uppercase font-bold text-[10px]">Quantidade de Baterias</span>
                        <span className="text-green-highlight font-bold">{params.batteryCount} unidades</span>
                      </div>
                      <input
                        type="range"
                        min="5"
                        max="250"
                        step="1"
                        value={params.batteryCount}
                        onChange={(e) => setParams(prev => ({ ...prev, batteryCount: parseInt(e.target.value) }))}
                        className="w-full h-1 bg-green-dark border border-green-border/30 rounded-lg appearance-none cursor-pointer accent-green-highlight"
                      />
                      <span className="text-[9px] text-[#52525b] font-mono block leading-none">
                        Número de acumuladores cilíndricos de sódio instalados no barramento principal.
                      </span>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs font-mono">
                        <span className="text-zinc-400 uppercase font-bold text-[10px]">Amperagem por Bateria</span>
                        <span className="text-green-highlight font-bold">{params.batteryAmperage} A</span>
                      </div>
                      <input
                        type="range"
                        min="10"
                        max="300"
                        step="5"
                        value={params.batteryAmperage}
                        onChange={(e) => setParams(prev => ({ ...prev, batteryAmperage: parseInt(e.target.value) }))}
                        className="w-full h-1 bg-green-dark border border-green-border/30 rounded-lg appearance-none cursor-pointer accent-green-highlight"
                      />
                      <span className="text-[9px] text-[#52525b] font-mono block leading-none">
                        Capacidade de corrente nominal contínua de descarga por bateria de sódio.
                      </span>
                    </div>
                  </div>

                </div>
              </div>

              {/* CENTRAL DE INJEÇÃO E CONFIGURAÇÃO DE ERROS */}
              <div className="border border-green-border/40 bg-green-panel p-5 shadow-[0_4px_25px_rgba(0,0,0,0.5)]">
                <button
                  type="button"
                  onClick={() => setIsFaultsExpanded(!isFaultsExpanded)}
                  className="w-full flex items-center justify-between transition cursor-pointer text-left pb-1 border-b border-green-border/25"
                >
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-5 h-5 text-[#f43f5e]" />
                    <h3 className="font-mono text-xs uppercase text-white font-bold tracking-wider">
                      Configurar Erros & Falhas
                    </h3>
                    {(faults.generator1Failure || faults.batteryOverheat || faults.aiCommunicationLoss || faults.busShortCircuit) && (
                      <span className="animate-pulse bg-rose-950 border border-rose-500/50 text-rose-300 text-[8px] font-bold px-1.5 py-0.5 font-mono">
                        FALHA ATIVA
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono">
                    {isFaultsExpanded ? "Ocultar [-]" : "Expandir [+]"}
                  </span>
                </button>
                
                {isFaultsExpanded ? (
                  <div className="mt-4 space-y-3.5">
                    <p className="text-[10.5px] text-zinc-400 font-mono leading-relaxed mb-4 leading-snug">
                      Induza anomalias críticas no Power Management System (PMS) para testar a resiliência do sistema híbrido com baterias de sódio.
                    </p>

                    <div className="space-y-3.5 font-mono text-[10px]">
                      
                      {/* FAILURE 1: G1 MECHANICAL FAULT */}
                      <div className="bg-green-dark border border-green-border/25 p-2.5 flex items-center justify-between">
                        <div className="flex flex-col gap-0.5">
                          <span className="font-bold text-slate-105 uppercase text-[9.5px]">Falha no Gerador G1 (Caterpillar)</span>
                          <span className="text-[8.5px] text-zinc-500 uppercase leading-none">Simula desarme mecânico imediato</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setFaults(prev => ({ ...prev, generator1Failure: !prev.generator1Failure }))}
                          className={`px-2.5 py-1 text-[9px] font-bold uppercase border tracking-wider transition cursor-pointer ${
                            faults.generator1Failure
                              ? "bg-rose-950/40 text-rose-300 border-rose-500/50 shadow-[0_0_8px_rgba(244,63,94,0.1)]"
                              : "bg-green-panel border border-green-border/20 text-zinc-400 hover:text-white"
                          }`}
                        >
                          {faults.generator1Failure ? "Falha Ativa" : "NORMAL"}
                        </button>
                      </div>

                      {/* FAILURE 2: SODIUM BATTERY OVERHEAT */}
                      <div className="bg-green-dark border border-green-border/25 p-2.5 flex items-center justify-between">
                        <div className="flex flex-col gap-0.5">
                          <span className="font-bold text-slate-105 uppercase text-[9.5px]">Sobreaquecimento das Baterias</span>
                          <span className="text-[8.5px] text-zinc-500 uppercase leading-none">Célula Sódio acima de 350°C</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setFaults(prev => ({ ...prev, batteryOverheat: !prev.batteryOverheat }))}
                          className={`px-2.5 py-1 text-[9px] font-bold uppercase border tracking-wider transition cursor-pointer ${
                            faults.batteryOverheat
                              ? "bg-rose-950/40 text-rose-300 border-rose-500/50 shadow-[0_0_8px_rgba(244,63,94,0.1)]"
                              : "bg-green-panel border border-green-border/20 text-zinc-400 hover:text-white"
                          }`}
                        >
                          {faults.batteryOverheat ? "Falha Ativa" : "NORMAL"}
                        </button>
                      </div>

                      {/* FAILURE 3: AI COMM LOSS */}
                      <div className="bg-green-dark border border-green-border/25 p-2.5 flex items-center justify-between">
                        <div className="flex flex-col gap-0.5">
                          <span className="font-bold text-slate-105 uppercase text-[9.5px]">Perda de Sinal LSTM / IA</span>
                          <span className="text-[8.5px] text-zinc-500 uppercase leading-none">Simula erro de telemetria IA</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setFaults(prev => ({ ...prev, aiCommunicationLoss: !prev.aiCommunicationLoss }))}
                          className={`px-2.5 py-1 text-[9px] font-bold uppercase border tracking-wider transition cursor-pointer ${
                            faults.aiCommunicationLoss
                              ? "bg-rose-950/40 text-rose-300 border-rose-500/50 shadow-[0_0_8px_rgba(244,63,94,0.1)]"
                              : "bg-green-panel border border-green-border/20 text-zinc-400 hover:text-white"
                          }`}
                        >
                          {faults.aiCommunicationLoss ? "Falha Ativa" : "NORMAL"}
                        </button>
                      </div>

                      {/* FAILURE 4: BUS SHORT CIRCUIT */}
                      <div className="bg-green-dark border border-green-border/25 p-2.5 flex items-center justify-between">
                        <div className="flex flex-col gap-0.5">
                          <span className="font-bold text-slate-105 uppercase text-[9.5px]">Distorção de Barramento</span>
                          <span className="text-[8.5px] text-zinc-500 uppercase leading-none">Adiciona perdas e fuga elétrica</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => setFaults(prev => ({ ...prev, busShortCircuit: !prev.busShortCircuit }))}
                          className={`px-2.5 py-1 text-[10px] font-bold uppercase border tracking-wider transition cursor-pointer ${
                            faults.busShortCircuit
                              ? "bg-rose-950/40 text-rose-300 border-rose-500/50 shadow-[0_0_8px_rgba(244,63,94,0.1)]"
                              : "bg-green-panel border border-green-border/20 text-zinc-400 hover:text-white"
                          }`}
                        >
                          {faults.busShortCircuit ? "Falha Ativa" : "NORMAL"}
                        </button>
                      </div>

                    </div>
                  </div>
                ) : (
                  <p className="text-[9.5px] text-zinc-500 font-mono leading-relaxed mt-2 leading-snug">
                    Clique para expandir e induzir falhas artificiais de teste de resiliência sem prejudicar a usabilidade central dos comandos.
                  </p>
                )}
              </div>

              {/* SAVINGS CARD BOX SUMMARY */}
              <div className="border border-green-border bg-green-panel p-5 shadow-[0_4px_15px_rgba(0,133,66,0.03)] flex flex-col justify-between relative overflow-hidden">
                <div className="absolute -top-10 -left-10 w-24 h-24 bg-green-highlight/5 rounded-full blur-2xl" />
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <TrendingDown className="w-5 h-5 text-green-highlight" />
                    <h4 className="font-mono text-xs uppercase font-bold text-slate-100 tracking-wider">
                      Indicadores de Redução 24h
                    </h4>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                    <div className="bg-green-dark p-3 border border-green-border/30">
                      <span className="block text-[9px] text-[#52525b] uppercase leading-none mb-1">CO2 Reduzido</span>
                      <span className="text-green-highlight text-lg font-bold">-{summaryMetrics.hybridAi.co2SavingsPercent}%</span>
                      <span className="block text-[8px] text-zinc-500 mt-1 uppercase">Eco-Pegada</span>
                    </div>

                    <div className="bg-green-dark p-3 border border-green-border/30">
                      <span className="block text-[9px] text-[#52525b] uppercase leading-none mb-1">Óleo Diesel</span>
                      <span className="text-green-highlight text-lg font-bold">-{summaryMetrics.hybridAi.fuelSavingsPercent}%</span>
                      <span className="block text-[8px] text-zinc-500 mt-1 uppercase">De Consumo</span>
                    </div>
                  </div>

                  <div className="bg-green-dark border border-green-border/30 p-3 text-[10.5px] text-zinc-300 font-mono leading-relaxed leading-snug">
                    Ao operar com <strong>LSTM + MPC</strong>, a bateria atua como mitigadora de transientes dinâmicos de carga em mar agitado, diminuindo em até <strong className="text-white">40%</strong> a exigência instantânea de combustível fóssil nos motores diesel Caterpillar.
                  </div>
                </div>
              </div>

            </div>

            {/* COLUMN 2: PRIMARY SCHEMATIC ARCHITECTURE MAP (8 SPAN) */}
            <div className="lg:col-span-8 space-y-6">

              {/* CENTRAL DE ALARMES DO SISTEMA PMS (Interactive alarm pane) */}
              <div className={`border p-4 transition duration-300 font-mono shadow-[0_4px_20px_rgba(0,0,0,0.5)] ${
                activeAlarms.length > 0 
                  ? "bg-[#11050a] border-rose-950 shadow-[0_0_15px_rgba(244,63,94,0.05)]" 
                  : "bg-green-panel border-green-border"
              }`}>
                <div className="flex items-center justify-between pb-2 border-b border-zinc-850 mb-3 flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-2.5 h-2.5 rounded-full ${activeAlarms.length > 0 ? 'bg-rose-500 animate-ping' : 'bg-green-accent'}`} style={{ backgroundColor: activeAlarms.length > 0 ? undefined : '#008542' }} />
                    <span className="text-xs uppercase font-bold tracking-wider text-slate-100">
                      Central de Diagnóstico & Alarmes do PMS ({activeAlarms.length})
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {activeAlarms.length > 0 && (
                      <button
                        type="button"
                        onClick={() => setFaults({
                          generator1Failure: false,
                          batteryOverheat: false,
                          aiCommunicationLoss: false,
                          busShortCircuit: false
                        })}
                        className="text-[9px] bg-rose-950/40 hover:bg-rose-900/60 text-rose-350 border border-rose-500/50 px-2 py-0.5 font-bold uppercase transition cursor-pointer"
                      >
                        Bypass / Reset Geral
                      </button>
                    )}
                    <span className="text-[10px] text-zinc-500 uppercase">Power Management System v4.0</span>
                  </div>
                </div>

                {activeAlarms.length === 0 ? (
                  <div className="flex items-center gap-2 text-green-highlight text-[10.5px]">
                    <ShieldCheck className="w-4 h-4 text-green-accent" />
                    <span className="font-bold tracking-wide">TODOS OS SISTEMAS DA EMBARCAÇÃO OPERANDO EM REGIME SEGURO E EFICIENTE</span>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {activeAlarms.map((alarm) => (
                      <div key={alarm.id} className={`p-2 border-l-2 flex items-center justify-between gap-2.5 text-[10px] leading-relaxed transition ${
                        alarm.type === "critical" 
                          ? "bg-rose-950/20 border-rose-500 text-rose-300" 
                          : "bg-amber-950/10 border-amber-500 text-amber-350"
                      }`}>
                        <div className="flex items-start gap-2.5 flex-1">
                          <AlertTriangle className={`w-3.5 h-3.5 flex-shrink-0 mt-0.5 ${alarm.type === "critical" ? "text-rose-400" : "text-amber-400"}`} />
                          <div>
                            <span className="font-bold uppercase text-[8.5px] block leading-none mb-1 opacity-75">
                              [{alarm.system}]
                            </span>
                            <span>{alarm.msg}</span>
                          </div>
                        </div>

                        {["err-g1", "err-bat", "err-ai", "err-bus"].includes(alarm.id) ? (
                          <button
                            type="button"
                            onClick={() => {
                              if (alarm.id === "err-g1") setFaults(prev => ({ ...prev, generator1Failure: false }));
                              if (alarm.id === "err-bat") setFaults(prev => ({ ...prev, batteryOverheat: false }));
                              if (alarm.id === "err-ai") setFaults(prev => ({ ...prev, aiCommunicationLoss: false }));
                              if (alarm.id === "err-bus") setFaults(prev => ({ ...prev, busShortCircuit: false }));
                            }}
                            className="bg-black/40 hover:bg-black/70 text-[9px] uppercase font-bold tracking-wider px-2 py-1 text-white border border-rose-500/40 hover:border-green-accent/60 transition cursor-pointer shrink-0"
                          >
                            Reparar Canal
                          </button>
                        ) : (
                          <span className="text-[8px] text-zinc-550 uppercase font-mono italic shrink-0">
                            Aviso Operacional
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              {/* SYNOPTIC GRID CARDS */}
              <div className="border border-green-border/45 bg-green-panel p-5">
                <div className="flex items-center justify-between pb-3 border-b border-green-border/25 mb-4 flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-green-highlight" />
                    <h3 className="font-mono text-xs uppercase text-white font-bold tracking-wider">
                      Esquema do Fluxo Híbrido Proposto
                    </h3>
                  </div>
                  <div className="flex items-center gap-3 font-mono text-[10px]">
                    <span className="flex items-center gap-1"><span className="w-2 h-2 bg-green-accent" /> Potência CA</span>
                    <span className="flex items-center gap-1"><span className="w-2 h-2 bg-green-highlight" /> Potência CC</span>
                    <span className="flex items-center gap-1"><span className="w-2 h-2 bg-[#f43f5e]" /> Carga Auxiliar</span>
                  </div>
                </div>

                <p className="text-[11px] text-zinc-400 font-mono leading-relaxed mb-6 leading-snug">
                  Representação ativa dos fluxos de transferência gerencial do painel do PSV World Diamond sob regime simulado na <strong className="text-white font-bold">Hora: {activeTelemetry.timeString}</strong>.
                </p>

                {/* VISUAL SYNOPTIC FLOW CONTAINER */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-stretch font-mono text-xs relative">
                  
                  {/* GENERATOR RACK LAYOUT BLOCK (4 SPANS) */}
                  <div className="md:col-span-4 bg-[#070b13]/85 p-3.5 border border-[#14532d]/30 flex flex-col justify-between space-y-3 relative">
                    <div className="absolute top-0 left-0 bg-[#166534] text-white text-[8px] font-bold tracking-widest px-2 uppercase py-0.5">
                      01 / GERADORES DIESEL
                    </div>
                    
                    <div className="space-y-2 pt-4">
                      {VESSEL_SPECIFICATIONS.generators.map((gen, idx) => {
                        const powerGenerated = activeTelemetry.genPower[idx];
                        const loadPercent = Math.round((powerGenerated / gen.maxPower) * 100);
                        const isGenOnline = powerGenerated > 0;
                        const isG1Failed = idx === 0 && faults.generator1Failure;
                        
                        return (
                          <div
                            key={gen.id}
                            className={`p-2.5 border transition ${
                              isG1Failed
                                ? "bg-rose-955/20 border-rose-500/60 shadow-[0_0_10px_rgba(239,68,68,0.15)] opacity-100"
                                : isGenOnline 
                                  ? "bg-green-dark border-green-border shadow-[0_0_8px_rgba(0,133,66,0.05)]" 
                                  : "bg-[#0b1424] border-zinc-800 opacity-60"
                            }`}
                          >
                            <div className="flex items-center justify-between text-[10px] mb-1">
                              <span className="font-bold text-slate-100 uppercase">G{gen.id} ({gen.type})</span>
                              <span className={`px-1 text-[8px] font-bold ${
                                isG1Failed
                                  ? "text-rose-400 bg-rose-950/80 animate-pulse border border-rose-500/30"
                                  : isGenOnline 
                                    ? "text-green-accent bg-green-panel border border-green-border/20" 
                                    : "text-zinc-500 bg-zinc-900"
                              }`}>
                                {isG1Failed ? "FALHA CRÍTICA" : (isGenOnline ? "ONLINE" : "OFFLINE")}
                              </span>
                            </div>
                            <div className="grid grid-cols-2 gap-2 text-[9px] text-zinc-400">
                              <span>Max: {gen.maxPower} kW</span>
                              <span className="text-right font-bold text-slate-300">
                                Ativo: {formatkW(powerGenerated)}
                              </span>
                            </div>
                            
                            {/* Generator loading bar */}
                            <div className="h-1 bg-zinc-900 mt-2 relative overflow-hidden">
                              <div 
                                className={`h-full transition-all duration-500 ${
                                  isG1Failed ? "bg-rose-600 animate-pulse" : loadPercent > 85 ? "bg-rose-500" : "bg-green-accent"
                                }`} 
                                style={{ width: `${isG1Failed ? 0 : Math.min(100, loadPercent)}%` }} 
                              />
                            </div>
                            <div className="flex justify-between text-[7.5px] text-zinc-600 mt-0.5">
                              <span>0%</span>
                              <span className={`font-bold ${isG1Failed ? "text-rose-500" : "text-green-accent/80"}`}>
                                {isG1Failed ? "DESACTIVADO" : `${loadPercent}% Carga`}
                              </span>
                              <span>100%</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* SWITCHBOARD MIDDLEWARE CONNECTOR (4 SPANS) */}
                  <div className="md:col-span-4 flex flex-col justify-between gap-4 font-mono text-[10px]">
                    
                    {/* Quadro Elétrico Principal box */}
                    <div className="bg-green-dark border border-green-border p-4 flex flex-col items-center justify-center text-center relative flex-1 min-h-[140px]">
                      <div className="absolute top-1 left-1.5 text-[8.5px] font-bold tracking-widest text-green-accent uppercase">
                        SISTEMA DE BARRAMENTO
                      </div>
                      <Layers className="w-8 h-8 text-green-highlight mb-2 animate-pulse" />
                      <h4 className="font-bold text-slate-100 uppercase text-xs tracking-wider">
                        Quadro Elétrico Principal
                      </h4>
                      <p className="text-[10px] text-green-highlight font-bold mt-1">
                        Carga no Barramento: {formatkW(activeTelemetry.loadDemand)}
                      </p>
                      <p className="text-[9px] text-zinc-500 mt-1 uppercase">
                        Conversores de Frequência CC/CA
                      </p>
                    </div>

                    {/* SODIUM BATTERY PACK CONNECTION STATUS */}
                    <div className="bg-green-dark border border-green-border/40 p-3.5 relative overflow-hidden flex flex-col justify-between">
                      <div className="absolute top-0 left-0 bg-green-highlight text-green-dark text-[8px] font-bold tracking-widest px-2 uppercase py-0.25">
                        02 / BANCO DE SÓDIO ({dynamicCapacityLabel})
                      </div>
                      
                      <div className="space-y-2 pt-3">
                        <div className="flex items-center justify-between text-[10px] uppercase font-bold text-slate-200 mt-1">
                          <span>Química de Sódio</span>
                          <span className={`${faults.batteryOverheat ? "text-rose-400" : "text-green-accent"}`}>
                            {faults.batteryOverheat ? "BYPASS TÉRMICO" : SODIUM_BATTERY_SPECS.chemistry.split("/")[0]}
                          </span>
                        </div>
                        
                        {/* Power flow indicator */}
                        <div className="bg-green-panel p-2 border border-green-border/20 flex items-center justify-between">
                          <span className="text-[9px] text-zinc-500">Fluxo Instantâneo</span>
                          <span className={`font-mono font-bold text-[10px] ${
                            faults.batteryOverheat
                              ? "text-rose-455 animate-pulse"
                              : activeTelemetry.batteryPower > 0 
                                ? "text-[#f43f5e]" 
                                : activeTelemetry.batteryPower < 0 
                                  ? "text-green-highlight" 
                                  : "text-zinc-500"
                          }`}>
                            {faults.batteryOverheat
                              ? "BLOQUEADO / TEMP OUT"
                              : activeTelemetry.batteryPower > 0 
                                ? `DESCARGA: +${activeTelemetry.batteryPower} kW` 
                                : activeTelemetry.batteryPower < 0 
                                  ? `RECARGA: -${Math.abs(activeTelemetry.batteryPower)} kW` 
                                  : "STANDBY (Ocioso)"}
                          </span>
                        </div>

                        {/* Battery status charging grid bar */}
                        <div className={`h-2 w-full relative border overflow-hidden ${faults.batteryOverheat ? "bg-[#110508] border-rose-950" : "bg-green-dark border-green-border/30"}`}>
                          <div 
                            className={`h-full transition-all duration-1000 ${faults.batteryOverheat ? "bg-rose-700" : "bg-green-highlight"}`} 
                            style={{ width: `${faults.batteryOverheat ? 0 : activeTelemetry.batterySoc}%` }} 
                          />
                        </div>
                        <div className="flex items-center justify-between text-[8px] text-[zinc-500]">
                          <span>ESTADO DE CARGA: <strong className={faults.batteryOverheat ? "text-rose-400" : "text-green-highlight"}>{faults.batteryOverheat ? "Bypass Ativo" : `${activeTelemetry.batterySoc}% SOC`}</strong></span>
                          <span className="text-zinc-400 font-bold">{params.batteryCount}x {params.batteryVoltage}</span>
                        </div>
                      </div>
                    </div>

                  </div>

                  {/* AUXILIARY & PROPULSION ACTUATORS BLOCK (4 SPANS) */}
                  <div className="md:col-span-4 bg-green-dark p-3.5 border border-green-border/35 flex flex-col justify-between space-y-4 relative">
                    <div className="absolute top-0 left-0 bg-green-panel border border-green-border/25 text-white text-[8px] font-bold tracking-widest px-2 uppercase py-0.5">
                      03 / CONSUMIDORES ATIVOS
                    </div>
                    
                    {/* Propulsion thrusters stats block */}
                    <div className="bg-green-dark p-3 border border-green-border/20 mt-3">
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <Gauge className="w-4 h-4 text-green-highlight animate-spin" style={{ animationDuration: `${params.vesselSpeed > 0 ? (16 - params.vesselSpeed) : 0}s` }} />
                        <h4 className="text-[10px] uppercase font-bold text-slate-100">Propulsores Azimutais</h4>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-[9px] text-zinc-400 font-mono">
                        <span>Motor Elétrico 1:</span>
                        <span className="font-bold text-slate-300 text-right">
                          {formatkW(Math.round(activeTelemetry.propulsionLoad / 2))}
                        </span>
                        <span>Motor Elétrico 2:</span>
                        <span className="font-bold text-slate-300 text-right">
                          {formatkW(Math.round(activeTelemetry.propulsionLoad / 2))}
                        </span>
                      </div>
                      <p className="text-[8px] text-zinc-500 mt-2 text-right uppercase tracking-wide">
                        RPM: {(params.vesselSpeed * 22).toFixed(0)} • Propulsão Naval Ativa
                      </p>
                    </div>

                    {/* Aux hotel load stats box */}
                    <div className="bg-green-dark p-3 border border-green-border/20">
                      <div className="flex items-center gap-1.5 mb-1.5">
                        <Zap className="w-4 h-4 text-green-highlight" />
                        <h4 className="text-[10px] uppercase font-bold text-slate-100">Hotelaria & Cargas Aux</h4>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-[9px] text-zinc-400 font-mono">
                        <span>Auxiliar:</span>
                        <span className="font-bold text-slate-300 text-right">
                          {formatkW(activeTelemetry.hotelLoad)}
                        </span>
                      </div>
                      <p className="text-[8px] text-zinc-500 mt-2 leading-tight uppercase">
                        Pumps, HVAC, Ventilação, Equipamento de Convés ativado.
                      </p>
                    </div>

                  </div>

                </div>

              </div>

              {/* TIMELINE INTERACTIVE MULTI-CHART (CUSTOM PREMIUM SVG CHART) */}
              <div className="border border-green-border bg-green-panel p-5">
                
                <div className="flex items-center justify-between pb-3 border-b border-green-border/25 mb-4 flex-wrap gap-2">
                  <div className="flex items-center gap-2">
                    <LineChart className="w-5 h-5 text-green-highlight" />
                    <h3 className="font-mono text-xs uppercase text-white font-bold tracking-wider">
                      Perfil Operacional Simulado de Demanda de Carga (24 h)
                    </h3>
                  </div>
                  <div className="flex items-center gap-3 text-[10px] font-mono font-bold uppercase">
                    <span className="flex items-center gap-1"><span className="w-2.5 h-[2px] bg-green-accent block" /> Demanda Total</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-[2px] bg-[#fb7185] block" /> G1+2+3+4 Diesel</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-[2px] bg-[#eab308] block" /> Recarga Sódio</span>
                  </div>
                </div>

                <p className="text-[11px] text-zinc-450 font-mono leading-relaxed mb-4 leading-snug">
                  Curva simulada de consumo de energia de {params.profile.toUpperCase()} baseada em histórico de ondas e arrasto. Clique em qualquer hora para ajustar os indicadores ou aperte PLAY para avançar temporizado.
                </p>

                {/* GRAPH CUSTOM RENDER CONTAINER */}
                {(() => {
                  const maxVisibleLoad = Math.max(
                    5000,
                    ...SIMULATION_PROFILES[params.profile].map((pt) => {
                      const tel = getTelemetryData(pt.hour, params);
                      const totalGens = tel.genPower.reduce((a, b) => a + b, 0);
                      return Math.max(tel.loadDemand, totalGens);
                    })
                  );
                  return (
                    <div className="relative pt-1 h-44 bg-green-dark border border-green-border/25 p-3 select-none">
                      
                      {/* Grid background lines */}
                      <div className="absolute inset-0 flex flex-col justify-between p-3 pointer-events-none opacity-20">
                        <div className="border-b border-green-border/25 w-full" />
                        <div className="border-b border-green-border/25 w-full" />
                        <div className="border-b border-green-border/25 w-full" />
                        <div className="border-b border-green-border/25 w-full" />
                      </div>

                      {/* Left scale metrics vertical */}
                      <div className="absolute top-2 left-2 text-[8px] font-mono text-zinc-600 space-y-3 uppercase pointer-events-none leading-none">
                        <span>{formatkW(Math.round(maxVisibleLoad))}</span>
                        <br />
                        <span>{formatkW(Math.round(maxVisibleLoad / 2))}</span>
                        <br />
                        <span>0 kW</span>
                      </div>

                      {/* Actual custom high fidelity telemetry drawing */}
                      <div className="w-full h-full relative px-6 py-2">
                        
                        {/* SVG GRAPH LINE DRAWING USING MATHEMATIC PROFILE VALUES */}
                        <svg className="w-full h-full overflow-visible pointer-events-none" preserveAspectRatio="none" viewBox="0 0 24 100">
                          
                          {/* Area of diesel generators power */}
                          <path
                            d={`M 0,100 ${SIMULATION_PROFILES[params.profile].map((pt, i) => {
                              const tel = getTelemetryData(pt.hour, params);
                              const totalGeneratorsPowerSum = tel.genPower.reduce((a, b) => a + b, 0);
                              const yPercent = 100 - (totalGeneratorsPowerSum / maxVisibleLoad) * 100;
                              return `L ${i},${yPercent}`;
                            }).join(" ")} L 23,100 Z`}
                            fill="rgba(244, 63, 94, 0.05)"
                            stroke="rgba(244, 63, 94, 0.3)"
                            strokeWidth="1.5"
                          />

                          {/* Line load demand */}
                          <path
                            d={SIMULATION_PROFILES[params.profile].map((pt, i) => {
                              const tel = getTelemetryData(pt.hour, params);
                              const yPercent = 100 - (tel.loadDemand / maxVisibleLoad) * 100;
                              return `${i === 0 ? "M" : "L"} ${i},${yPercent}`;
                            }).join(" ")}
                            fill="none"
                            stroke="#008542"
                            strokeWidth="2"
                            strokeDasharray="1.5"
                          />

                          {/* Interactive vertical Hour handle marker indicator */}
                          <line
                            x1={selectedHour}
                            y1="0"
                            x2={selectedHour}
                            y2="100"
                            stroke="#FFD100"
                            strokeWidth="0.5"
                            strokeDasharray="2"
                            className="animate-pulse"
                          />

                          {/* Circle on current active selected point */}
                          {(() => {
                            const currentTelPoint = getTelemetryData(selectedHour, params);
                            const cyPoint = 100 - (currentTelPoint.loadDemand / maxVisibleLoad) * 100;
                            return (
                              <circle
                                cx={selectedHour}
                                cy={cyPoint}
                                r="1.8"
                                fill="#FFD100"
                                stroke="white"
                                strokeWidth="0.5"
                                className="ping-glow"
                              />
                            );
                          })()}

                        </svg>

                        {/* Interactive columns for hover selection */}
                        <div className="absolute inset-0 flex justify-between px-6 pointer-events-auto">
                          {SIMULATION_PROFILES[params.profile].map((pt, i) => (
                            <button
                              key={pt.hour}
                              onClick={() => setSelectedHour(pt.hour)}
                              className="w-full group relative h-full flex flex-col justify-end pb-1 font-mono transition cursor-pointer"
                              title={`Ver dados simulados para a hora ${pt.timeLabel}`}
                            >
                              {/* Hover highlight column */}
                              <div className="absolute inset-y-0 left-0 right-0 border-l border-r border-green-border/30 transition opacity-0 group-hover:opacity-40 bg-green-panel/10" />
                            </button>
                          ))}
                        </div>

                      </div>

                    </div>
                  );
                })()}

                {/* HORIZONT TIMELINE COMPONENT INTERACTIVE BAR CONTROLLER */}
                <div className="mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 font-mono text-[10.5px] border-t border-green-border/25 pt-4">
                  
                  {/* Playback action timeline buttons */}
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => setIsPlaying(!isPlaying)}
                      className={`h-8 px-4 flex items-center gap-2 font-bold uppercase transition rounded-none cursor-pointer ${
                        isPlaying 
                          ? "bg-green-panel text-green-highlight border border-green-highlight/50" 
                          : "bg-green-highlight hover:bg-green-panel text-green-dark border border-green-highlight hover:text-white"
                      }`}
                    >
                      {isPlaying ? (
                        <>
                          <Pause className="w-3.5 h-3.5 fill-current" /> Pause
                        </>
                      ) : (
                        <>
                          <Play className="w-3.5 h-3.5 fill-current" /> Play Simulação
                        </>
                      )}
                    </button>
                    
                    <button
                      onClick={() => setSelectedHour(12)}
                      className="px-3 h-8 bg-green-dark hover:bg-green-panel border border-green-border text-zinc-300 font-bold uppercase cursor-pointer"
                    >
                      Meio-Dia Reset
                    </button>
                  </div>

                  {/* Indicator info digital scale text readout */}
                  <div className="flex items-center gap-3 leading-none md:text-right">
                    <span>SELECIONADA: <strong className="text-white text-xs">{activeTelemetry.timeString}</strong></span>
                    <span className="text-zinc-650 font-bold">|</span>
                    <span>CARGA: <strong className="text-green-highlight font-bold">{formatkW(activeTelemetry.loadDemand)}</strong></span>
                    <span className="text-zinc-650 font-bold">|</span>
                    <span>DUMP SÓDIO: <strong className="text-green-highlight font-bold">{formatkW(activeTelemetry.batteryPower)}</strong></span>
                  </div>

                </div>

              </div>

            </div>

          </div>
        </>
      )}

        {activeTab === "battery" && (
          <div className="border border-green-border bg-green-panel p-6 space-y-6">
            
            <div className="flex items-center gap-3 pb-3 border-b border-green-border/25">
              <Award className="w-6 h-6 text-green-highlight animate-pulse" />
              <div>
                <h3 className="font-display text-lg text-white font-bold leading-none uppercase">
                  Banco de Baterias de Sódio-Níquel-Cloreto (Brochure oficial e INMETRO)
                </h3>
                <p className="text-[11px] text-zinc-500 font-mono tracking-widest mt-0.5">
                  ESPECIFICAÇÕES DE OPERABILIDADE E SEGURANÇA INTEGRAL
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs font-mono">
              
              {/* Advantages Sodium batteries */}
              <div className="space-y-4">
                <h4 className="text-green-highlight uppercase font-bold tracking-wider text-xs">
                  Vantagens Tecnológicas Exclusivas
                </h4>
                
                <ul className="space-y-3 text-zinc-300">
                  <li className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-green-accent shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-100 uppercase">Total Isenção de Fuga Térmica (Thermal Runaway):</strong>
                      <p className="text-[11px] text-zinc-450 mt-1">
                        Sua química exclusiva é baseada em metais abundantes (sal marinho, níquel e ferro), operando sem eletrólitos líquidos inflamáveis. Perfeito para o restrito espaço blindado de máquinas navais.
                      </p>
                    </div>
                  </li>

                  <li className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-green-accent shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-100 uppercase">Tolerância a Altas e Baixas Temperaturas Externas:</strong>
                      <p className="text-[11px] text-zinc-450 mt-1">
                        Diferente das baterias químicas convencionais inflamáveis (que perdem rendimento ou entram em risco sob calor extremo), o composto sódio-metal halide opera contido dentro de vasos sob vácuo duplo, estável entre -40°C e +65°C externos.
                      </p>
                    </div>
                  </li>

                  <li className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-green-accent shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-100 uppercase">Ciclo de Uso Prolongado (Zero Degradação Ativa):</strong>
                      <p className="text-[11px] text-zinc-450 mt-1">
                        Não degrada quimicamente quando mantida descarregada por períodos longos, oferecendo durabilidade estimada de até 15 anos com taxa zero de autodescarga.
                      </p>
                    </div>
                  </li>

                  <li className="flex items-start gap-2.5">
                    <Check className="w-4 h-4 text-green-accent shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-100 uppercase">Sustentabilidade de Matérias Primas:</strong>
                      <p className="text-[11px] text-zinc-450 mt-1">
                        Utiliza compostos naturais abundantes e alumínio de fácil reciclagem integral. Livre de materiais geopoliticamente escassos como cobalto ou agregados refinados.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>

              {/* Physical specifications and INMETRO values */}
              <div className="bg-green-dark border border-green-border/25 p-5 flex flex-col justify-between">
                
                <div className="space-y-4">
                  <h4 className="text-green-highlight uppercase font-bold tracking-wider text-xs">
                    Dados Técnicos Certificados (INMETRO)
                  </h4>

                  <div className="space-y-2 text-[11px]">
                    <div className="flex justify-between border-b border-green-border/20 py-1">
                      <span className="text-zinc-500 uppercase">Quantidade de Baterias</span>
                      <strong className="text-green-highlight font-bold">{params.batteryCount} Unidades</strong>
                    </div>
                    <div className="flex justify-between border-b border-green-border/20 py-1">
                      <span className="text-zinc-500 uppercase">Amperagem por Bateria</span>
                      <strong className="text-green-highlight font-bold">{params.batteryAmperage} A</strong>
                    </div>
                    <div className="flex justify-between border-b border-green-border/20 py-1">
                      <span className="text-zinc-500 uppercase">Tensão Ativa</span>
                      <strong className="text-slate-200">{params.batteryVoltage} ({parsedVoltage} Vcc)</strong>
                    </div>
                    <div className="flex justify-between border-b border-green-border/20 py-1">
                      <span className="text-zinc-500 uppercase">Capacidade Total Integrada</span>
                      <strong className="text-slate-100 font-bold">{dynamicCapacityLabel}</strong>
                    </div>
                    <div className="flex justify-between border-b border-green-border/20 py-1">
                      <span className="text-zinc-500 uppercase">Amperagem Total do Banco</span>
                      <strong className="text-slate-200">{totalBankAmperage.toLocaleString()} Ah</strong>
                    </div>
                    <div className="flex justify-between border-b border-green-border/20 py-1">
                      <span className="text-zinc-500 uppercase">Temperatura Celular Operativa</span>
                      <strong className="text-slate-200">{SODIUM_BATTERY_SPECS.operatingTemp}</strong>
                    </div>
                    <div className="flex justify-between border-b border-green-border/20 py-1">
                      <span className="text-zinc-500 uppercase">Potência Máxima de Descarga (Pico)</span>
                      <strong className="text-slate-200">{SODIUM_BATTERY_SPECS.maxDischargeRate}</strong>
                    </div>
                    <div className="flex justify-between border-b border-green-border/20 py-1">
                      <span className="text-zinc-500 uppercase">Máxima Taxa de Carga</span>
                      <strong className="text-slate-200">{SODIUM_BATTERY_SPECS.maxChargeRate}</strong>
                    </div>
                    <div className="flex justify-between border-b border-green-border/20 py-1">
                      <span className="text-zinc-500 uppercase">Eficiência de Conversão</span>
                      <strong className="text-green-highlight">{SODIUM_BATTERY_SPECS.efficiencyRoundtrip}% (Ida e Volta)</strong>
                    </div>
                  </div>
                </div>

                <div className="mt-8 pt-4 border-t border-green-border/25 bg-green-panel/50 p-4 rounded text-xs select-none">
                  <div className="flex items-center gap-2 mb-2.5 text-green-highlight font-bold uppercase text-[10px] tracking-wider">
                    <Award className="w-4 h-4 shrink-0 text-green-accent" />
                    <span>Conformidade Técnica & Certificações de Segurança</span>
                  </div>
                  <p className="text-[11px] text-zinc-300 leading-relaxed mb-4">
                    As baterias de <strong className="text-white font-semibold">SÓDIO</strong> comercializadas pela <strong className="text-green-highlight font-semibold font-mono">Ctritech</strong> atendem plenamente às normas técnicas nacionais e internacionais listadas a seguir, garantindo máxima <strong className="text-white font-semibold">SEGURANÇA</strong>, <strong className="text-white font-semibold">CONFIABILIDADE</strong> e <strong className="text-white font-semibold">DESEMPENHO</strong> em aplicações industriais severas e de suporte offshore:
                  </p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px] font-mono text-zinc-400">
                    <div className="bg-slate-950/60 border border-green-border/15 p-2.5 rounded-sm flex flex-col justify-between">
                      <span className="text-green-highlight font-bold text-[11px]">IEC 62984</span>
                      <span className="text-[9px] text-zinc-500 mt-1 lowercase leading-tight">padrão internacional de segurança e desempenho para baterias de alta temperatura</span>
                    </div>
                    <div className="bg-slate-950/60 border border-green-border/15 p-2.5 rounded-sm flex flex-col justify-between">
                      <span className="text-green-highlight font-bold text-[11px]">IEC 60529</span>
                      <span className="text-[9px] text-zinc-500 mt-1 lowercase leading-tight">graus de proteção providos por invólucros (código IP de estanqueidade)</span>
                    </div>
                    <div className="bg-slate-950/60 border border-green-border/15 p-2.5 rounded-sm flex flex-col justify-between text-left">
                      <span className="text-green-highlight font-bold text-[11px] leading-tight">IEC 61000-6-2 / EM 61000-6-4</span>
                      <span className="text-[9px] text-zinc-500 mt-1 lowercase leading-tight">imunidade e emissão de compatibilidade eletromagnética (EMC) industrial</span>
                    </div>
                    <div className="bg-slate-950/60 border border-green-border/15 p-2.5 rounded-sm flex flex-col justify-between">
                      <span className="text-green-highlight font-bold text-[11px]">CE Mark</span>
                      <span className="text-[9px] text-zinc-500 mt-1 lowercase leading-tight">certificado de livre circulação em conformidade de saúde e segurança europeia</span>
                    </div>
                    <div className="bg-slate-950/60 border border-green-border/15 p-2.5 rounded-sm flex flex-col justify-between sm:col-span-2">
                      <div className="flex justify-between items-center flex-wrap gap-1">
                        <span className="text-green-highlight font-bold text-[11px]">UL 9540A & UL 1973 ed.2</span>
                        <span className="text-[8px] tracking-wider uppercase font-extrabold bg-green-highlight/10 text-green-accent px-1.5 py-0.5 border border-green-border/20 rounded-sm">Segurança Crítica</span>
                      </div>
                      <span className="text-[9px] text-zinc-500 mt-1 lowercase leading-tight">ensaios de runaway térmico estruturado e segurança para baterias estacionárias offshore</span>
                    </div>
                  </div>
                </div>

              </div>

            </div>

          </div>
        )}

        {activeTab === "comparison" && (
          <div className="border border-green-border bg-green-panel p-6 space-y-6">
            
            <div className="flex items-center gap-3 pb-3 border-b border-green-border/25">
              <TrendingDown className="w-6 h-6 text-green-highlight" />
              <div>
                <h3 className="font-display text-lg text-white font-bold leading-none uppercase">
                  Balanço Operativo de Economias de Óleo Diesel & CO2
                </h3>
                <p className="text-[11px] text-zinc-500 font-mono tracking-widest mt-0.5">
                  COMPARATIVO MÉDIO GLOBAL PARA O REGIME OPERACIONAL DO NAVIO (24 h)
                </p>
              </div>
            </div>

            <p className="text-xs text-zinc-400 font-mono leading-relaxed max-w-3xl leading-snug">
              A tabela de resultados indica a economia expressiva proporcionada pelo sistema híbrido inteligente em comparação com a operação convencional, calculada considerando a totalidade do ciclo operacional de 24 horas da embarcação PSV de referência. Por favor, verifique a correspondência com a brochura de projeto:
            </p>

            <div className="overflow-x-auto border border-zinc-850">
              <table className="w-full text-left border-collapse font-mono text-[11px] text-zinc-300">
                <thead>
                  <tr className="bg-slate-900/40 text-zinc-550 border-b border-zinc-800 uppercase text-[9.5px]">
                    <th className="p-3">Sistema de Operação</th>
                    <th className="p-3 text-right">Consumo Diesel Total (Est)</th>
                    <th className="p-3 text-right">Redução de Óleo</th>
                    <th className="p-3 text-right">Emissões de CO2 equivalentes</th>
                    <th className="p-3 text-right">Redução de Emissões</th>
                    <th className="p-3 text-right">Eficiência Energética (%)</th>
                    <th className="p-3 text-right">Prevenção / Reserva Giratória</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-850">
                  <tr className="hover:bg-green-panel/40">
                    <td className="p-3 font-bold text-slate-400">Convencional (Diesel-Elétrico Puro)</td>
                    <td className="p-3 text-right text-slate-300">
                      {(summaryMetrics.conventional.fuelTotal).toLocaleString()} Litros
                    </td>
                    <td className="p-3 text-right text-zinc-500">—</td>
                    <td className="p-3 text-right text-slate-300">
                      {(summaryMetrics.conventional.co2Total).toLocaleString()} kg
                    </td>
                    <td className="p-3 text-right text-zinc-500">—</td>
                    <td className="p-3 text-right text-rose-450">{summaryMetrics.conventional.avgEfficiency}%</td>
                    <td className="p-3 text-right text-rose-400 font-bold uppercase text-[9.5px]">
                      Risco Alto de Blecaute em DP
                    </td>
                  </tr>

                  <tr className="bg-[#003d1c]/30 hover:bg-[#003d1c]/50 transition">
                    <td className="p-3 font-bold text-white flex items-center gap-1.5">
                      <span className="p-0.5 bg-green-highlight text-green-dark text-[7.5px] font-bold">IA ATIVO</span>
                      Híbrido com Bateria de Íons de Sódio (LSTM + MPC)
                    </td>
                    <td className="p-3 text-right text-green-highlight font-bold">
                      {(summaryMetrics.hybridAi.fuelTotal).toLocaleString()} Litros
                    </td>
                    <td className="p-3 text-right text-green-accent font-semibold text-xs">
                      -{summaryMetrics.hybridAi.fuelSavingsPercent}% Economizado
                    </td>
                    <td className="p-3 text-right text-green-highlight font-bold">
                      {(summaryMetrics.hybridAi.co2Total).toLocaleString()} kg
                    </td>
                    <td className="p-3 text-right text-green-accent font-semibold text-xs">
                      -{summaryMetrics.hybridAi.co2SavingsPercent}% Reduzido
                    </td>
                    <td className="p-3 text-right text-green-highlight font-bold text-xs">
                      {summaryMetrics.hybridAi.avgEfficiency}% ({summaryMetrics.hybridAi.efficiencyGainPp} p.p. Superior)
                    </td>
                    <td className="p-3 text-right text-green-highlight font-bold uppercase text-[9.5px]">
                      Isenção de Fuga Térmica / Segurança Total
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-[10.5px] font-mono pt-4 leading-relaxed bg-[#002311]/50 border border-green-border/25 p-4">
              <div className="text-zinc-400">
                <span className="font-bold text-slate-200 block mb-1">RETIRE OS GERADORES INATIVOS</span>
                No regime tradicional de Dynamic Positioning, todos os geradores são ativados a baixas cargas para mitigar desastres se algum pifar. Sob o <strong>MPC</strong>, as baterias cobrem qualquer queda em milissegundos, salvando diesel precioso.
              </div>
              <div className="text-zinc-400">
                <span className="font-bold text-slate-200 block mb-1">CO2 E PENALIDADES DA IMO</span>
                Reduzir até <strong>35% de CO2</strong> permite que a frota Damen PSV cumpra com as exigentes metas de descarbonização da IMO (Organização Marítima Internacional) planejadas para 2030 / 2050.
              </div>
              <div className="text-zinc-400">
                <span className="font-bold text-slate-200 block mb-1">CUSTOS OPERACIONAIS (OPEX)</span>
                A diminuição de óleo combustível reduz diretamente os custos fixos operais diários de fretamento para as seguradoras de marcas como Petrobras no polo de apoio onshore/offshore do Pré-Sal.
              </div>
            </div>

          </div>
        )}

        {activeTab === "faq" && (
          <div className="border border-green-border bg-green-panel p-6 space-y-6">
            <div className="flex items-center gap-3 pb-3 border-b border-green-border/25">
              <Award className="w-6 h-6 text-green-highlight" />
              <div>
                <h3 className="font-display text-base text-white font-bold leading-none uppercase">
                  Manual de Respostas Técnicas & Conectividade Co-Piloto
                </h3>
                <p className="text-[11px] text-zinc-500 font-mono tracking-widest mt-1">
                  RESPOSTAS OFICIAIS DA BROCHURE DO SISTEMA DE PROPULSÃO DO DAMEN PSV 3300
                </p>
              </div>
            </div>

            <p className="text-xs text-zinc-400 font-mono leading-relaxed max-w-3xl leading-snug">
              Selecione qualquer uma das perguntas essenciais da certificação para ler as respostas operacionais detalhadas formuladas com base no projeto elétrico de propulsão e bateria de sódio de 125 Vcc.
            </p>

            <div className="space-y-4">
              {AI_PRESETS.map((q, idx) => {
                const isOpen = expandedFaq === idx;
                const answer = PRESETS_ANSWERS[q];
                return (
                  <div 
                    key={idx}
                    className={`border transition duration-200 ${
                      isOpen ? "border-green-accent/55 bg-gradient-to-r from-[#003d1c]/45 to-[#002311]" : "border-zinc-800 bg-slate-900/40 hover:bg-green-panel/20"
                    }`}
                  >
                    <button
                      onClick={() => setExpandedFaq(isOpen ? null : idx)}
                      className="w-full flex items-center justify-between p-4 font-mono text-xs uppercase text-left text-slate-100 font-bold select-none outline-none focus:outline-none cursor-pointer"
                    >
                      <div className="flex items-center gap-3 pr-4">
                        <span className={`w-5 h-5 flex items-center justify-center font-bold text-[10px] ${isOpen ? "bg-green-highlight text-green-dark" : "bg-[#0b1424] text-zinc-550"}`}>
                          0{idx + 1}
                        </span>
                        <span className={isOpen ? "text-green-highlight" : "text-slate-200"}>{q}</span>
                      </div>
                      <span className={`text-[12px] font-bold shrink-0 transition-transform duration-200 ${isOpen ? "rotate-180 text-green-highlight" : "text-zinc-500"}`}>
                        {isOpen ? "▲" : "▼"}
                      </span>
                    </button>

                    {isOpen && (
                      <div className="px-5 pb-5 pt-2 border-t border-green-border/25 font-mono text-zinc-300 text-xs leading-relaxed space-y-3 whitespace-pre-wrap animate-fadeIn">
                        {answer.split("\n").map((para, i) => (
                          <p key={i}>
                            {sanitizeResponseText(para)}
                          </p>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Quick helper info block */}
            <div className="bg-green-dark border border-green-border/25 p-4 font-mono text-[10.5px] text-zinc-400 leading-relaxed rounded-none">
              <p className="font-bold text-slate-200 uppercase mb-1">💡 Dica Operacional para o Comandante</p>
              Você também pode clicar e submeter qualquer uma destas perguntas usando a barra rápida de Perguntas Rápidas logo abaixo do chat do Co-Piloto IA à direita, ou digitar suas dúvidas na barra de busca para interagir com o modelo do Gemini.
            </div>
          </div>
        )}

        {/* BOTTOM DOUBLE COLUMN SECTION: AI ADVISORY CHAT ON THE RIGHT BAR (PORTUGUESE FOR USER CONTROLS) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* DETAILED DIAGRAM METHODOLOGY (5 SPANS) */}
          <div className="lg:col-span-5 border border-green-border bg-green-panel p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-4 pb-2 border-b border-green-border/25">
                <Layers className="w-5 h-5 text-green-highlight" />
                <h3 className="font-mono text-xs uppercase text-white font-bold tracking-wider">
                  Desenho Metodológico do Algoritmo IA
                </h3>
              </div>

              {/* AI Block Flow Layout Graphic */}
              <div className="space-y-4 font-mono text-[10.5px] text-zinc-400 leading-relaxed pt-2">
                <div className="border border-green-border/30 bg-green-dark p-3 flex items-center justify-between gap-3 relative">
                  <div className="w-1.5 h-full bg-green-accent absolute inset-y-0 left-0" />
                  <div className="pl-2">
                    <span className="text-[10px] text-green-highlight font-bold block mb-0.5">FASE 1: PREVISÃO (REDE NEURAL LSTM)</span>
                    Mecanismo inteligente que recebe dados passados de agitação das ondas (arrasto no casco) e preve a carga exigida nos motores para os próximos 15 minutos.
                  </div>
                </div>

                <div className="flex justify-center py-0.5">
                  <span className="text-green-border/55 font-bold">↓</span>
                </div>

                <div className="border border-green-border/30 bg-green-dark p-3 flex items-center justify-between gap-3 relative">
                  <div className="w-1.5 h-full bg-green-accent/80 absolute inset-y-0 left-0" />
                  <div className="pl-2">
                    <span className="text-[10px] text-green-highlight font-bold block mb-0.5">FASE 2: DETECÇÃO DE MARGEM (MPC)</span>
                    O algoritmo Model Predictive Control recalcula as restrições a cada 1 minute de intervalo, selecionando a combinação ótima de geradores ligados que operam na zona ideal de curva combustível.
                  </div>
                </div>

                <div className="flex justify-center py-0.5">
                  <span className="text-green-border/55 font-bold">↓</span>
                </div>

                <div className="border border-green-border/30 bg-green-dark p-3 flex items-center justify-between gap-3 relative">
                  <div className="w-1.5 h-full bg-[#052e16] absolute inset-y-0 left-0" />
                  <div className="pl-2">
                    <span className="text-[10px] text-green-highlight font-bold block mb-0.5">FASE 3: BUFFERING DE TRANSITÓRIOS</span>
                    Quaisquer picos curtos não previstos são instantaneamente providenciados pelo Banco de Sódio de 2 MWh. Sem emissão extra de combustível fóssil.
                  </div>
                </div>

                <div className="flex justify-center py-0.5">
                  <span className="text-green-border/55 font-bold">↓</span>
                </div>

                <div className="border border-indigo-500/25 bg-[#080d19] p-3 flex items-center justify-between gap-3 relative">
                  <div className="w-1.5 h-full bg-indigo-600 absolute inset-y-0 left-0" />
                  <div className="pl-2">
                    <span className="text-[10px] text-indigo-400 font-bold block mb-0.5">FASE 4: ANÁLISE ANTISPOOFING</span>
                    Módulo de segurança cibernética que usa o modelo TrAISformer de previsão de trajetórias de embarcações e o teste estatístico de Mahalanobis (MB) para validar a continuidade das leituras de posicionamento dinâmico diante de anomalias de transponder.
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-green-border/20 text-[10px] text-zinc-500 font-mono text-center uppercase">
                Tecnologia de Propulsão Híbrida Inteligente • Ctritech Ctri6000 Series
              </div>
            </div>
          </div>

          {/* AI COPI-PILOT TERMINAL WIDGET (7 SPANS) */}
          <div className="lg:col-span-7 border border-green-border bg-green-panel flex flex-col justify-between overflow-hidden shadow-[0_10px_35px_-10px_rgba(0,0,0,0.8)]">
            
            {/* AI Assistant header bar */}
            <div className="p-4 bg-gradient-to-r from-[#003d1c] to-[#002311] border-b border-green-border/45 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="p-1 px-1.5 bg-green-highlight text-green-dark text-[9px] font-mono uppercase font-bold">
                  SÉNIOR CO-PILOTO IA
                </span>
                <div>
                  <h4 className="font-display font-medium text-xs text-white uppercase tracking-wider leading-none">
                    Assistente Técnico de Máquinas
                  </h4>
                  <span className="text-[9.5px] text-zinc-500 font-mono tracking-wide uppercase block mt-1">
                    Powered by server-side Google Gemini 3.5 Flash
                  </span>
                </div>
              </div>

              {/* Status online green dot */}
              <div className="flex items-center gap-1.5 font-mono text-[9px] text-[#FFD100]">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#FFD100] opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-[#008542]"></span>
                </span>
                SISTEMA PRONTO
              </div>
            </div>

            {/* MESSAGE DIALOG LIST LOG */}
            <div className="flex-1 p-4 space-y-4 max-h-[350px] overflow-y-auto bg-slate-950/70 select-text font-mono text-xs">
              <AnimatePresence initial={false}>
                {advisoryMessages.map((msg, index) => {
                  const isAssistant = msg.role === "assistant";
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${isAssistant ? "justify-start" : "justify-end"}`}
                    >
                      <div className={`p-3.5 max-w-[85%] font-mono text-xs leading-relaxed space-y-2 ${
                        isAssistant
                          ? "bg-[#09151c]/90 border border-green-border/30 text-[#f1f5f9] relative"
                          : "bg-green-panel/40 border border-green-border/40 text-white rounded-none"
                      }`}>
                        
                        {/* Text formatting support for clean paragraph splits */}
                        <div className="whitespace-pre-wrap leading-relaxed">
                          {(isAssistant ? sanitizeResponseText(msg.content) : msg.content).split("\n").map((para, i) => (
                            <p key={i} className={para.trim() === "" ? "h-2" : "mb-2 last:mb-0"}>
                              {para}
                            </p>
                          ))}
                        </div>

                        <span className="block text-[8px] text-zinc-500 text-right uppercase tracking-wider pt-1 border-t border-zinc-800/20 mt-2">
                          {msg.timestamp} • {isAssistant ? "Scribecross System" : "Operador"}
                        </span>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
              <div ref={chatEndRef} />
            </div>

            {/* PRESET CHIPS QUICK TRIGGER CONFLICT */}
            <div className="px-4 py-3 bg-[#070b13] border-t border-green-border/25 space-y-1.5">
              <span className="text-[8.5px] font-mono text-zinc-500 uppercase tracking-widest block font-bold">
                Perguntas Rápidas do Brochure de Máquinas:
              </span>
              <div className="flex flex-wrap gap-1.5 select-none w-full">
                {AI_PRESETS.map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => handlePresetTrigger(p)}
                    disabled={aiLoading}
                    className="text-[9.5px] font-mono text-zinc-400 hover:text-green-highlight bg-slate-900 border border-zinc-800 hover:border-green-border px-2 py-1 text-left line-clamp-1 truncate transition disabled:opacity-50 cursor-pointer"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* MESSAGE DIALOG INPUT CONTROLLER */}
            <div className="p-4 bg-slate-950 border-t border-green-border/25 font-mono text-xs">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendAdvisoryQuery(userQuery);
                }}
                className="flex items-stretch gap-2.5"
              >
                <input
                  type="text"
                  value={userQuery}
                  onChange={(e) => setUserQuery(e.target.value)}
                  placeholder="Pergunte ao Co-Piloto de Sódio (ex: 'vantagens das baterias de sódio 125Vcc')"
                  disabled={aiLoading}
                  className="flex-1 px-3 py-2 bg-green-dark/40 border border-zinc-850 focus:border-green-border text-white placeholder-zinc-650 outline-none text-xs rounded-none font-mono focus:ring-1 focus:ring-green-border/20"
                />
                
                <button
                  type="submit"
                  disabled={aiLoading || !userQuery.trim()}
                  className="bg-green-highlight hover:bg-green-panel disabled:bg-zinc-850 disabled:text-zinc-650 text-green-dark hover:text-white px-4 flex items-center justify-center font-bold tracking-widest uppercase transition rounded-none text-xs shrink-0 cursor-pointer"
                >
                  {aiLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin text-green-dark" />
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-1" /> Enviar
                    </>
                  )}
                </button>
              </form>
            </div>

          </div>

        </div>

      </main>

      {/* FOOTER METADATA BRAND */}
      <footer className="border-t border-green-border/25 bg-green-dark py-8 px-6 text-center text-[10px] text-zinc-500 mt-12 shrink-0 font-mono tracking-wider uppercase">
        <p>&copy; {new Date().getFullYear()} Jariane Santos. Todos os direitos reservados.</p>
        <p className="text-[9px] text-zinc-600 lowercase normal-case tracking-normal max-w-3xl mx-auto mt-2 leading-relaxed">
          sistema preditivo autônomo projetado para o suporte e controle de carga em tempo real do banco de baterias de sódio Ctritech 125Vcc no polo Damen PSV 3300.
        </p>
      </footer>

    </div>
  );
}
