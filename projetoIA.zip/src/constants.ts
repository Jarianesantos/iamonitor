import { OperationalProfile } from "./types";

export interface ProfileLoadPoint {
  hour: number;
  timeLabel: string;
  baseDemandkW: number; // base kW required
}

export const VESSEL_SPECIFICATIONS = {
  name: "PSV World Diamond",
  design: "Damen PSV 3300",
  type: "Platform Supply Vessel (PSV)",
  length: "73,35 m",
  beam: "16,80 m",
  deadweight: "2.159 t",
  propulsionType: "Diesel-Elétrica Híbrida",
  operationalScope: "Apoio offshore no pré-sal brasileiro",
  totalInstalledPower: "4.650 kW",
  generators: [
    { id: 1, type: "Caterpillar 3512C", maxPower: 1200, fuelCurveCoeff: 0.24 }, // L/kWh
    { id: 2, type: "Caterpillar 3512C", maxPower: 1200, fuelCurveCoeff: 0.24 },
    { id: 3, type: "Caterpillar C32", maxPower: 925, fuelCurveCoeff: 0.26 },
    { id: 4, type: "Caterpillar C32", maxPower: 925, fuelCurveCoeff: 0.26 },
  ]
};

export const SODIUM_BATTERY_SPECS = {
  chemistry: "Sódio-Cloreto de Níquel / Íons de Sódio",
  capacity: "2 MWh",
  voltageOptions: ["125Vcc"],
  certifications: ["IEC 62984", "IEC 60529", "IEC 61000-6-2", "EM 61000-6-4", "CE Mark", "UL 9540A", "UL 1973 ed.2"],
  safetyFeatures: "Não inflamável, sem risco de fuga térmica (thermal runaway), tolerante a curto-circuito, 100% reciclável",
  operatingTemp: "250°C a 320°C (temperatura celular protegida internamente sob vácuo, isolamento classe térmica superior)",
  socLimits: { min: 10, max: 95, optimal: 50 },
  maxDischargeRate: "1200 kW (Pico)",
  maxChargeRate: "800 kW",
  efficiencyRoundtrip: 92
};

// 24 Hour operational load profile curves
export const SIMULATION_PROFILES: Record<OperationalProfile, ProfileLoadPoint[]> = {
  transit: [
    { hour: 0, timeLabel: "00:00", baseDemandkW: 3100 },
    { hour: 1, timeLabel: "01:00", baseDemandkW: 3050 },
    { hour: 2, timeLabel: "02:00", baseDemandkW: 3200 },
    { hour: 3, timeLabel: "03:00", baseDemandkW: 3400 },
    { hour: 4, timeLabel: "04:00", baseDemandkW: 3050 },
    { hour: 5, timeLabel: "05:00", baseDemandkW: 2900 },
    { hour: 6, timeLabel: "06:00", baseDemandkW: 3100 },
    { hour: 7, timeLabel: "07:00", baseDemandkW: 3350 },
    { hour: 8, timeLabel: "08:00", baseDemandkW: 3400 },
    { hour: 9, timeLabel: "09:00", baseDemandkW: 3150 },
    { hour: 10, timeLabel: "10:00", baseDemandkW: 3000 },
    { hour: 11, timeLabel: "11:00", baseDemandkW: 2950 },
    { hour: 12, timeLabel: "12:00", baseDemandkW: 3250 },
    { hour: 13, timeLabel: "13:00", baseDemandkW: 3300 },
    { hour: 14, timeLabel: "14:00", baseDemandkW: 3400 },
    { hour: 15, timeLabel: "15:00", baseDemandkW: 3100 },
    { hour: 16, timeLabel: "16:00", baseDemandkW: 3050 },
    { hour: 17, timeLabel: "17:00", baseDemandkW: 3120 },
    { hour: 18, timeLabel: "18:00", baseDemandkW: 3480 },
    { hour: 19, timeLabel: "19:00", baseDemandkW: 3550 },
    { hour: 20, timeLabel: "20:00", baseDemandkW: 3200 },
    { hour: 21, timeLabel: "21:00", baseDemandkW: 3100 },
    { hour: 22, timeLabel: "22:00", baseDemandkW: 3050 },
    { hour: 23, timeLabel: "23:00", baseDemandkW: 3150 }
  ],
  dp: [
    { hour: 0, timeLabel: "00:00", baseDemandkW: 2200 },
    { hour: 1, timeLabel: "01:00", baseDemandkW: 2600 },
    { hour: 2, timeLabel: "02:00", baseDemandkW: 2100 },
    { hour: 3, timeLabel: "03:00", baseDemandkW: 1800 },
    { hour: 4, timeLabel: "04:00", baseDemandkW: 2500 },
    { hour: 5, timeLabel: "05:00", baseDemandkW: 2950 },
    { hour: 6, timeLabel: "06:00", baseDemandkW: 3300 },
    { hour: 7, timeLabel: "07:00", baseDemandkW: 2400 },
    { hour: 8, timeLabel: "08:00", baseDemandkW: 2000 },
    { hour: 9, timeLabel: "09:00", baseDemandkW: 2500 },
    { hour: 10, timeLabel: "10:00", baseDemandkW: 3100 },
    { hour: 11, timeLabel: "11:00", baseDemandkW: 3450 },
    { hour: 12, timeLabel: "12:00", baseDemandkW: 2300 },
    { hour: 13, timeLabel: "13:00", baseDemandkW: 2100 },
    { hour: 14, timeLabel: "14:00", baseDemandkW: 1950 },
    { hour: 15, timeLabel: "15:00", baseDemandkW: 2700 },
    { hour: 16, timeLabel: "16:00", baseDemandkW: 3200 },
    { hour: 17, timeLabel: "17:00", baseDemandkW: 3500 },
    { hour: 18, timeLabel: "18:00", baseDemandkW: 2800 },
    { hour: 19, timeLabel: "19:00", baseDemandkW: 2150 },
    { hour: 20, timeLabel: "20:00", baseDemandkW: 1900 },
    { hour: 21, timeLabel: "21:00", baseDemandkW: 2600 },
    { hour: 22, timeLabel: "22:00", baseDemandkW: 3100 },
    { hour: 23, timeLabel: "23:00", baseDemandkW: 2450 }
  ],
  maneuver: [
    { hour: 0, timeLabel: "00:00", baseDemandkW: 2500 },
    { hour: 1, timeLabel: "01:00", baseDemandkW: 2800 },
    { hour: 2, timeLabel: "02:00", baseDemandkW: 3200 },
    { hour: 3, timeLabel: "03:00", baseDemandkW: 4000 }, // rapid speed change
    { hour: 4, timeLabel: "04:00", baseDemandkW: 3700 },
    { hour: 5, timeLabel: "05:00", baseDemandkW: 2600 },
    { hour: 6, timeLabel: "06:00", baseDemandkW: 2100 },
    { hour: 7, timeLabel: "07:00", baseDemandkW: 2400 },
    { hour: 8, timeLabel: "08:00", baseDemandkW: 3100 },
    { hour: 9, timeLabel: "09:00", baseDemandkW: 3900 },
    { hour: 10, timeLabel: "10:00", baseDemandkW: 3800 },
    { hour: 11, timeLabel: "11:00", baseDemandkW: 2900 },
    { hour: 12, timeLabel: "12:00", baseDemandkW: 2200 },
    { hour: 13, timeLabel: "13:00", baseDemandkW: 2100 },
    { hour: 14, timeLabel: "14:00", baseDemandkW: 2500 },
    { hour: 15, timeLabel: "15:00", baseDemandkW: 3250 },
    { hour: 16, timeLabel: "16:00", baseDemandkW: 3950 },
    { hour: 17, timeLabel: "17:00", baseDemandkW: 3400 },
    { hour: 18, timeLabel: "18:00", baseDemandkW: 2700 },
    { hour: 19, timeLabel: "19:00", baseDemandkW: 2300 },
    { hour: 20, timeLabel: "20:00", baseDemandkW: 2500 },
    { hour: 21, timeLabel: "21:00", baseDemandkW: 3300 },
    { hour: 22, timeLabel: "22:00", baseDemandkW: 3850 },
    { hour: 23, timeLabel: "23:00", baseDemandkW: 2600 }
  ],
  port: [
    { hour: 0, timeLabel: "00:00", baseDemandkW: 250 },
    { hour: 1, timeLabel: "01:00", baseDemandkW: 250 },
    { hour: 2, timeLabel: "02:00", baseDemandkW: 240 },
    { hour: 3, timeLabel: "03:00", baseDemandkW: 260 },
    { hour: 4, timeLabel: "04:00", baseDemandkW: 300 }, // discharging some cargo
    { hour: 5, timeLabel: "05:00", baseDemandkW: 350 },
    { hour: 6, timeLabel: "06:00", baseDemandkW: 400 },
    { hour: 7, timeLabel: "07:00", baseDemandkW: 420 },
    { hour: 8, timeLabel: "08:00", baseDemandkW: 380 },
    { hour: 9, timeLabel: "09:00", baseDemandkW: 300 },
    { hour: 10, timeLabel: "10:00", baseDemandkW: 280 },
    { hour: 11, timeLabel: "11:00", baseDemandkW: 270 },
    { hour: 12, timeLabel: "12:00", baseDemandkW: 250 },
    { hour: 13, timeLabel: "13:00", baseDemandkW: 250 },
    { hour: 14, timeLabel: "14:00", baseDemandkW: 260 },
    { hour: 15, timeLabel: "15:00", baseDemandkW: 280 },
    { hour: 16, timeLabel: "16:00", baseDemandkW: 320 },
    { hour: 17, timeLabel: "17:00", baseDemandkW: 350 },
    { hour: 18, timeLabel: "18:00", baseDemandkW: 410 },
    { hour: 19, timeLabel: "19:00", baseDemandkW: 400 },
    { hour: 20, timeLabel: "20:00", baseDemandkW: 300 },
    { hour: 21, timeLabel: "21:00", baseDemandkW: 260 },
    { hour: 22, timeLabel: "22:00", baseDemandkW: 250 },
    { hour: 23, timeLabel: "23:00", baseDemandkW: 250 }
  ]
};

// Preset AI Advisory triggers for quick click
export const AI_PRESETS = [
  "Como o algoritmo LSTM antecipa variações de carga com base nas ondas?",
  "Explique o papel do banco de baterias de sódio de 125Vcc como amortecedor de transientes.",
  "Qual a eficiência média do MPC em comparação com a operação manual no modo DP?",
  "Como integrar as técnicas da dissertação de Julio C. Ramos (TrAISformer + Classificador MB) para mitigar riscos de spoofing no DP?",
  "Como funciona o teste estatístico da Marinha (MB) baseado na distância de Mahalanobis para validar a continuidade de trajetórias?",
  "Como a química de sódio-cloreto de níquel se comporta contra fuga térmica em águas tropicais?"
];

export const PRESETS_ANSWERS: Record<string, string> = {
  "Como o algoritmo LSTM antecipa variações de carga com base nas ondas?": 
    "A rede neural LSTM (Long Short-Term Memory) é treinada utilizando as séries temporais das medições históricas de arrasto no casco naval do PSV World Diamond e leituras de acelerômetros do MRU (Motion Reference Unit).\n\n" +
    "- Horizonte de Previsão de 15 Minutos: O algoritmo identifica as frequências de encontro das ondas em tempo real e calcula estatisticamente a flutuação dinâmica de arrasto e ventos, prevendo com exatidão científica as demandas de carregamento que os propulsores azimutais exigirão para os próximos 15 minutos.\n" +
    "- Rampas Otimizadas: Isso possibilita ao sistema subir ou descer a geração de forma suave e programada, evitando picos repentinos de estresse e sem a necessidade de manter geradores extras sob a preventiva reserva giratória ociosa.",

  "Explique o papel do banco de baterias de sódio de 125Vcc como amortecedor de transientes.":
    "Em sistemas diesel-elétricos tradicionais navais, oscilações rápidas no movimento das ondas impõem transientes mecânicos severos aos motores a diesel (os chamados load steps). Os geradores necessitam de alguns segundos de resposta pneumático-mecânica, levando a queima incompleta de óleo diesel, fumaça negra e aceleração de fadiga estrutural.\n\n" +
    "- Amortecimento em Sub-Milissegundos (Peak Shaving): O banco de baterias de sódio-metal halide de 125Vcc responde instantaneamente (em frações de milissegundos) a qualquer degrau positivo ou negativo de potência.\n" +
    "- Estabilização do Barramento: Ele atua como amortecedor, inserindo a potência complementar de pico na rede ou absorvendo energia regenerativa em reversões rápidas de hélices de posicionamento dinâmico (DP). Assim, os geradores diesel rodam perfeitamente em carga estável e constante no ponto termodinâmico ideal, erradicando micro-desgastes.",

  "Qual a eficiência média do MPC em comparação com a operação manual no modo DP?":
    "No modo clássico de Posicionamento Dinâmico (DP), diretrizes marítimas de segurança (como solicitações de redundância DNV-GL) obrigavam os chefes de máquinas a manter múltiplos geradores ligados (ex: os 4 online simultaneamente) como reserva ativa (reserva giratória) contra blecaute súbito.\n\n" +
    "- Ineficiência Manual: Operar 4 motores a 25% de carga típica puxa a eficiência energética global da planta para cerca de 65% a 74%, sofrendo carbonização por baixa carga térmica e alto consumo específico.\n" +
    "- Otimização Ativa MPC: O controle preditivo (Model Predictive Control) calcula matematicamente em tempo real a distribuição perfeita de carga a cada 1 minuto. Como o banco de baterias de sódio de 2 MWh está homologado com resposta síncrona ultra-rápida, ele supre qualquer queda secundária.\n" +
    "- Eficiência a 93%: Isso permite que o MPC desligue com total segurança os geradores excedentes desnecessários, mantendo os geradores ativos rodando perto de sua carga de máxima eficiência (75% a 85% de carga), onde o rendimento térmico do motor atinge 93%, reduzindo o OPEX de combustível em até 40%.",

  "Como integrar as técnicas da dissertação de Julio C. Ramos (TrAISformer + Classificador MB) para mitigar riscos de spoofing no DP?":
    "A dissertação desenvolvida na COPPE/UFRJ por Julio Cesar Medeiros dos Anjos Ramos propõe um sistema robusto em duas etapas para detectar e correlacionar trajetórias com adulteração de identificadores (MMSI) do AIS, sendo altamente relevante para mitigar riscos de colisão cibernética na navegação de apoio offshore em modo DP.\n\n" +
    "- Previsão de Trajetória Bidirecional (TrAISformer): Caso uma embarcação desative intencionalmente o transmissor ou rasure dados (MMSI spoofing) para ocultar infrações, a arquitetura de Transformers neurais (TrAISformer) é empregada de forma recursiva para estimar as previsões de rota para frente (forward) a partir das últimas leituras conhecidas e projetar o passado (backward) de eventuais alvos suspeitos próximos.\n" +
    "- Classificação Multicritério Robustecida: Através de algoritmos como Random Forest, SVM e o algoritmo especial desenvolvido pela Marinha do Brasil (MB), o sistema classifica se duas trajetórias correlatam-se ao mesmo navio com acurácia de até 96% (Dataset 5). Ao acoplar essa inteligência com o sistema de controle de posicionamento dinâmico (DP) do Damen PSV 3300, erradicamos o risco de falsos alvos e spoofing de GPS na praça de navegação.",

  "Como funciona o teste estatístico da Marinha (MB) baseado na distância de Mahalanobis para validar a continuidade de trajetórias?":
    "O algoritmo de associação de trajetórias da Marinha do Brasil (MB / IPqM), detalhado e validado na dissertação de Julio Cesar Ramos, é fundamentado em teste de hipótese Qui-Quadrado (chi-quadrado) e na Distância de Mahalanobis:\n\n" +
    "- Ajuste de Variância (Mahalanobis vs Euclidiana): Ao invés de usar a métrica de distância Euclidiana estática, a fórmula calcula o quadrado da distância de Mahalanobis entre duas trajetórias (vetor de diferença D), ponderando a variabilidade através da matriz de covariância inversa derivada de dados históricos. Isso absorve com maestria flutuações de maré, rajadas de vento e arrasto de rastro mecânico.\n" +
    "- Janela Deslizante e Limiar de Detecção: O algoritmo executa o teste de forma online usando uma janela deslizante (tamanho N) que gera avaliações sequenciais. A hipótese nula (as duas trajetórias pertencem ao mesmo navio) é aceita se a média estatística dos pontos estiver abaixo do limiar crítico para uma confiança de 99,5% com 2N graus de liberdade. Caso o número de sucessos atinja o limiar de detecção L, a fusão de trajetórias é validada de forma robusta e síncrona.",

  "Como a química de sódio-cloreto de níquel se comporta contra fuga térmica em águas tropicais?":
    "As baterias industriais de Sódio-Cloreto de Níquel operam internamente sob uma temperatura celular de 250°C a 320°C, encapsuladas hermeticamente dentro de um invólucro blindado com painéis de isolamento térmico a vácuo industrial.\n\n" +
    "Nas praças de máquinas navegando em climas tropicais rústicos (ex: litoral do Pré-Sal brasileiro), esta química exibe vantagens excepcionais sobre baterias clássicas:\n\n" +
    "1. Risco Zero de Fuga Térmica (Thermal Runaway): A reação química é intrinsecamente imune a incêndios e explosões. Mesmo sob curto-circuito pleno externo, esmagamento estrutural ou alagamento, a célula não libera gases explosivos nem propaga chamas.\n" +
    "2. Imunidade Climática Externa: Como o núcleo opera a mais de 250°C, variações térmicas locais da praça de máquinas (mesmo batendo 45°C diários) têm impacto zero na degradação ativa, eficiência de descarga ou vida útil da bateria.\n" +
    "3. Modularidade Auto-Regenerável: Se uma célula falha fisicamente, o cloreto de sódio se solidifica isolando-a eletricamente de forma inofensiva, blindando as células próximas e garantindo a continuidade absoluta da operação sem desligar a bateria."
};
