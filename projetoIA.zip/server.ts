import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import "dotenv/config";

// Lazy initialization of the Gemini client safely
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // API Health Endpoint
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      hasKey: !!process.env.GEMINI_API_KEY,
    });
  });

  // AI Advisory Advisor for Hybrid Propulsion Systems
  app.post("/api/ai-advisory", async (req, res) => {
    try {
      const { message, telemetry } = req.body;
      if (!message) {
        return res.status(400).json({ error: "Mensagem é obrigatória." });
      }

      const ai = getGeminiClient();
      if (!ai) {
        return res.status(500).json({
          error: "A chave API do Gemini (GEMINI_API_KEY) está ausente nas configurações do servidor. Por favor, adicione-a no painel lateral de Secrets."
        });
      }

      const telemetryContext = telemetry 
        ? `
[TELEMETRIA DO NAVIO EM TEMPO REAL]
- Embarcação: PSV World Diamond (Damen PSV 3300)
- Perfil Operacional Atual: ${telemetry.profile || "Transit"}
- Velocidade Ajustada: ${telemetry.vesselSpeed || 0} nós
- Estado do Mar (Beaufort): ${telemetry.seaState || 3} (Ondas e arrasto aumentados)
- Demanda Total de Carga (Hotel + Propulsão): ${telemetry.loadDemand || 0} kW
- Carga de Hotelaria (Auxiliar): ${telemetry.hotelLoad || 0} kW
- Carga de Propulsão: ${telemetry.propulsionLoad || 0} kW
- Geradores Diesel Ativos: ${telemetry.activeGeneratorsCount || 0} de 4 online
- Distribuição de Carga dos Geradores: G1=${telemetry.genPower?.[0] || 0}kW, G2=${telemetry.genPower?.[1] || 0}kW, G3=${telemetry.genPower?.[2] || 0}kW, G4=${telemetry.genPower?.[3] || 0}kW
- Banco de Baterias de Sódio:
  * Configuração: ${telemetry.batteryCount || 75} baterias de ${telemetry.batteryVoltage || "125Vcc"} / ${telemetry.batteryAmperage || 80} A por unidade
  * Capacidade Total do Banco: ${telemetry.batteryCapacityKWh ? (telemetry.batteryCapacityKWh >= 1000 ? (telemetry.batteryCapacityKWh / 1000).toFixed(2) + " MWh" : telemetry.batteryCapacityKWh + " kWh") : "750 kWh"}
  * State of Charge (SOC - Estado de Carga): ${telemetry.batterySoc || 50}%
  * Fluxo de Potência da Bateria: ${telemetry.batteryPower || 0} kW (${telemetry.batteryPower > 0 ? "DESCARREGANDO - Amortecendo Picos" : telemetry.batteryPower < 0 ? "CARREGANDO - Absorvendo excesso" : "INATIVO - Em espera"})
- Impacto Ambiental do Estado Atual:
  * Consumo instantâneo de combustível: ${telemetry.fuelFlowRate || 0} L/h
  * Emissões de CO2 equivalentes: ${telemetry.co2FlowRate || 0} kg/h
  * Eficiência Energética Global: ${telemetry.systemEfficiency || 0}%
  * Otimização inteligente por IA (LSTM+MPC): ${telemetry.aiOptimized ? "ATIVADA" : "DESATIVADA"}
`
        : "[Sem telemetria do navio disponível neste momento]";

      const systemPrompt = `Você é o "Co-Piloto de Propulsão Híbrida Diesel-Elétrica" — um especialista em Inteligência Artificial, engenharia naval de propulsão híbrida, e especializado nos sistemas acadêmico-científicos de segurança cibernética e previsão/classificação de trajetórias de embarcações baseados na dissertação de Mestrado (COPPE/UFRJ) e artigo técnico de Julio Cesar Medeiros dos Anjos Ramos (conduzido com Rosa M. M. Leão e Pablo Rangel da Marinha do Brasil/IPqM).
Sua missão é atuar como assessor sênior do Chefe de Máquinas e da Praça de Navegação da embarcação de apoio offshore "PSV World Diamond".

Utilizando as informações de telemetria reais enviadas pelo usuário, forneça análises de engenharia, diagnóstico energético, segurança marítima contra spoofing e insights de controle inteligente.

Você tem conhecimento especialista aprofundado sobre:
- **Previsão de Trajetórias com TrAISformer:** Modelagem de redes neurais profundas baseadas em Transformers para prever trajetórias futuras (forward) e passadas (backward) de navios em cenários de perda/tampering de dados AIS, identificando que maior frequência de amostragem aumenta a acurácia de previsão e que rotas com complexidade geográfica aceleram o crescimento de erros ao longo do tempo.
- **Associação de Trajetórias e Detecção de Spoofing:** Métodos de classificação como Random Forest (RF) de altíssima acurácia, Support Vector Machines (SVM) otimizadas com normalização logarítmica y' = log10(y+1) para redução de outliers, e o algoritmo de classificação especial da Marinha do Brasil (MB) baseado no teste de hipóteses Qui-Quadrado (X²) executado sobre uma janela deslizante utilizando a Distância de Mahalanobis (D Σ⁻¹ D^T) para comparar desvios das trajetórias previstas ponderados pela covariância histórica de posições e velocidades cartesianas.

Parâmetros e Regras de Tom e linguajar:
1. Responda estritamente em PORTUGUÊS brasileiro.
2. Seja técnico, ultra-profissional, objetivo e inspirador. Use terminologias navais apropriadas (ex: sping-reserve, reserva giratória, hotelaria, arrasto, posicionamento dinâmico DP, transientes de carga, curva de eficiência de combustível, desvio de Mahalanobis, teste de Wilcoxon, SFS para redução de atributos, métricas de haversine).
3. Destaque as vantagens exclusivas navais e de segurança das Baterias de Sódio (como tolerância superior a altas temperaturas, facilidade de reciclagem, isolamento térmico, ausência de risco de fuga térmica / thermal runaway, e uso de recursos abundantes como sal de cozinha).
4. Explique como o algoritmo LSTM preve a demanda com horizonte de 15 minutos e como o MPC recalcula em intervalos de 1 minuto a distribuição de potência para maximizar a economia de CO2 e diesel (até 40% de redução).
5. Escreva em formato de texto simples e legível. NÃO use marcações de negrito de forma alguma (com asteriscos como **) e NÃO use o símbolo de jogo da velha (#) para títulos ou cabeçalhos. Use espaçamentos normais para parágrafos e hifens (-) ou números para listas estruturadas sem usar negritos.`;

      const userContent = `${telemetryContext}
Pergunta/Solicitação do Operador de Máquinas: "${message}"`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: userContent,
        config: {
          systemInstruction: systemPrompt,
          temperature: 0.8,
        }
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Advisory error:", error);
      res.status(500).json({ error: error.message || "Ocorreu um erro no assistente de IA." });
    }
  });

  // Serve static assets in production, or mount Vite middleware in development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
